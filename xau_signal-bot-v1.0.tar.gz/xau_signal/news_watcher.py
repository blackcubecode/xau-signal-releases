"""News Watcher \u2014 alert berita high-impact USD."""
import os
import asyncio
import logging
from datetime import datetime, timedelta
import pytz
from telegram import Bot
from dotenv import load_dotenv
from news_filter import _fetch_feed

from paths import ENV_FILE
load_dotenv(ENV_FILE)

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
WIB = pytz.timezone("Asia/Jakarta")

CHECK_INTERVAL = 30 * 60  # 30 menit

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
logging.getLogger("httpx").setLevel(logging.CRITICAL)
logging.getLogger("httpcore").setLevel(logging.CRITICAL)
logging.getLogger("telegram.request").setLevel(logging.CRITICAL)
logger = logging.getLogger(__name__)

alerted = set()

WARN = "\u26A0\uFE0F"
NEWS = "\U0001F4F0"
BANK = "\U0001F3DB\uFE0F"
CLOCK = "\u23F0"
BULB = "\U0001F4A1"


async def check(bot):
    try:
        events = _fetch_feed()
        if not events:
            logger.warning("Feed kosong.")
            return

        now = datetime.now(pytz.UTC)
        win_start = now + timedelta(minutes=25)
        win_end = now + timedelta(minutes=35)

        for ev in events:
            if ev.get("impact", "").lower() != "high":
                continue
            if ev.get("country", "").upper() != "USD":
                continue
            try:
                ev_time = datetime.fromisoformat(ev["date"].replace("Z", "+00:00"))
            except Exception:
                continue

            if win_start <= ev_time <= win_end:
                eid = ev["title"] + "_" + ev["date"]
                if eid not in alerted:
                    wib = ev_time.astimezone(WIB).strftime("%H:%M WIB")
                    sep = "\u2501" * 18
                    msg = (
                        "\U0001F6D1 STOP TRADING\n"
                        "\u26A0\uFE0F HIGH IMPACT NEWS\n"
                        f"{sep}\n\n"
                        f"\U0001F4F0 {ev['title']}\n"
                        f"\U0001F3E6 Negara : US\n"
                        f"\U0001F550 Waktu : {wib}\n"
                        f"\u23F0 Dalam : 30 menit lagi\n\n"
                        "\U0001F6D1 HENTIKAN TRADING\n"
                        "\U0001F4CA Volatilitas XAUUSD tinggi\n"
                        "\U0001F550 Resume 30 menit setelah news\n\n"
                        "\U0001F6E1\uFE0F Jangan buka posisi baru\n\n"
                        "_Black Cube Code_"
                    )
                    await bot.send_message(chat_id=CHAT_ID, text=msg)
                    logger.info("Alert terkirim: %s", ev["title"])
                    alerted.add(eid)
                    if len(alerted) > 50:
                        alerted.clear()

        logger.info("Cek news OK, %d events", len(events))

    except Exception as e:
        logger.error("Gagal cek news: %s", e)


async def main():
    bot = Bot(token=TOKEN)
    logger.info("News watcher started. Interval %d menit", CHECK_INTERVAL // 60)
    while True:
        await check(bot)
        await asyncio.sleep(CHECK_INTERVAL)


if __name__ == "__main__":
    asyncio.run(main())
