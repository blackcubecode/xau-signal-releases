"""
BLACK CUBE CODE - Daily Report Scheduler V4

Fungsi:
- Kirim laporan harian setiap hari pukul 23:00 WIB
- Reset tiap hari (report mencakup 24 jam terakhir)
- Kirim QRIS support setelah report

Tracking signal hanya dilakukan oleh:
xau-collector.service
"""

import os
import asyncio
import logging
import sqlite3
import pytz

from datetime import datetime, timedelta
from dotenv import load_dotenv
from telegram import Bot

from winrate_v2 import build_report_message
from paths import BASE_DIR, DB_PATH, ENV_FILE, QRIS_PATH

# ============================================================
# CONFIG
# ============================================================

BASE_DIR = str(BASE_DIR)
load_dotenv(str(ENV_FILE))

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

WIB = pytz.timezone("Asia/Jakarta")

# Jadwal: setiap hari pukul 05:05 WIB (setelah NY close)
SEND_HOUR = 5
SEND_MINUTE = 5

# ============================================================
# LOGGING
# ============================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[
        logging.FileHandler(f"{BASE_DIR}/winrate_scheduler.log"),
        logging.StreamHandler(),
    ],
)

logging.getLogger("httpx").setLevel(logging.CRITICAL)
logging.getLogger("httpcore").setLevel(logging.CRITICAL)
logging.getLogger("telegram.request").setLevel(logging.CRITICAL)

logger = logging.getLogger(__name__)

# ============================================================
# SEND REPORT
# ============================================================


def has_pending_signals():
    """
    Cek apakah masih ada sinyal PENDING dalam 24 jam terakhir.
    Return True kalau masih ada pending.
    """
    try:
        conn = sqlite3.connect(str(DB_PATH))

        cutoff = (datetime.now() - timedelta(hours=24)).strftime("%Y-%m-%d %H:%M:%S")

        count = conn.execute(
            """
            SELECT COUNT(*) FROM signals
            WHERE status = 'PENDING'
            AND sent_at >= ?
            """,
            (cutoff,),
        ).fetchone()[0]

        conn.close()

        if count > 0:
            logger.info("Masih ada %d sinyal PENDING. Tunggu...", count)
            return True

        return False

    except Exception as e:
        logger.warning("Cek pending gagal: %s", e)
        return False


def get_trading_day_stats():
    """
    Cek stats trading day kemarin.
    Return dict: {total, wins, losses} atau None.
    """
    try:
        conn = sqlite3.connect(str(DB_PATH))
        conn.row_factory = sqlite3.Row

        # Trading day = kemarin (karena report dikirim pagi)
        now = datetime.now()
        yesterday = (now - timedelta(days=1)).strftime("%Y-%m-%d")

        total = conn.execute(
            "SELECT COUNT(*) FROM signals WHERE sent_at LIKE ?",
            (f"{yesterday}%",),
        ).fetchone()[0]

        wins = conn.execute(
            "SELECT COUNT(*) FROM signals WHERE status='WIN' AND sent_at LIKE ?",
            (f"{yesterday}%",),
        ).fetchone()[0]

        losses = conn.execute(
            "SELECT COUNT(*) FROM signals WHERE status='LOSS' AND sent_at LIKE ?",
            (f"{yesterday}%",),
        ).fetchone()[0]

        conn.close()

        return {
            "date": yesterday,
            "total": total,
            "wins": wins,
            "losses": losses,
        }

    except Exception as e:
        logger.warning("Cek trading day stats gagal: %s", e)
        return None


def is_weekend_day(date_str):
    """Cek apakah tanggal (YYYY-MM-DD) adalah Sabtu/Minggu."""
    try:
        dt = datetime.strptime(date_str, "%Y-%m-%d")
        return dt.weekday() >= 5
    except Exception:
        return False


async def send_winrate(bot):
    try:
        msg = build_report_message()

        await bot.send_message(
            chat_id=CHAT_ID,
            text=msg,
            disable_web_page_preview=True,
        )

        logger.info("Daily report terkirim.")

        # ----------------------------------------------------
        # QRIS
        # ----------------------------------------------------
        qris_path = str(QRIS_PATH)

        try:
            if os.path.exists(qris_path):
                with open(qris_path, "rb") as qr:
                    await bot.send_photo(
                        chat_id=CHAT_ID,
                        photo=qr,
                        caption="QRIS Support & Donation",
                    )
                logger.info("QRIS terkirim.")
            else:
                logger.warning("File QRIS tidak ditemukan: %s", qris_path)
        except Exception as e:
            logger.warning("Gagal kirim QRIS: %s", e)

    except Exception as e:
        logger.exception("Gagal kirim report: %s", e)


# ============================================================
# WAKTU TUNGGU SAMPAI JAM BERIKUTNYA
# ============================================================


def seconds_until_next_send():
    """Hitung detik sampai jam SEND_HOUR:SEND_MINUTE WIB berikutnya."""
    now = datetime.now(WIB)
    target = now.replace(
        hour=SEND_HOUR,
        minute=SEND_MINUTE,
        second=0,
        microsecond=0,
    )

    if target <= now:
        target = target + timedelta(days=1)

    delta = (target - now).total_seconds()
    return max(delta, 1)


# ============================================================
# MAIN LOOP
# ============================================================


async def loop_winrate(bot):
    logger.info(
        "Daily report akan dikirim setiap pukul %02d:%02d WIB",
        SEND_HOUR,
        SEND_MINUTE,
    )
    logger.info("Report dikirim setelah semua sinyal CLOSED (TP/SL)")

    while True:
        try:
            wait = seconds_until_next_send()
            hours = wait / 3600
            logger.info("Menunggu %.2f jam sampai jadwal berikutnya", hours)

            await asyncio.sleep(wait)

            now = datetime.now(WIB)
            logger.info(
                "Jadwal report tiba: %s",
                now.strftime("%Y-%m-%d %H:%M:%S WIB"),
            )

            day_stats = get_trading_day_stats()

            if day_stats is None:
                logger.warning("Gagal cek stats. Skip report.")
                continue

            trading_date = day_stats.get("date", "")
            total_signals = day_stats.get("total", 0)

            if is_weekend_day(trading_date):
                logger.info(
                    "SKIP report: trading day %s = weekend (market tutup)",
                    trading_date,
                )
                continue

            if total_signals == 0:
                logger.info(
                    "SKIP report: trading day %s = 0 sinyal",
                    trading_date,
                )
                continue

            logger.info(
                "Trading day %s: %d sinyal (W=%d, L=%d). Lanjut cek pending.",
                trading_date,
                total_signals,
                day_stats.get("wins", 0),
                day_stats.get("losses", 0),
            )

            max_wait = 0
            MAX_WAIT_SECONDS = 2 * 60 * 60

            while has_pending_signals():
                if max_wait >= MAX_WAIT_SECONDS:
                    logger.warning(
                        "Sudah tunggu 2 jam, masih ada pending. Kirim report apa adanya."
                    )
                    break

                logger.info("Tunggu 30 menit, cek pending lagi...")
                await asyncio.sleep(30 * 60)
                max_wait += 30 * 60

            logger.info("Semua sinyal CLOSED. Kirim report.")
            await send_winrate(bot)

        except Exception as e:
            logger.exception("Loop error: %s", e)
            await asyncio.sleep(60)


# ============================================================
# MAIN
# ============================================================


async def main():
    if not TOKEN or not CHAT_ID:
        logger.error("TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID tidak ada.")
        return

    bot = Bot(token=TOKEN)

    logger.info("BLACK CUBE CODE - Daily Report Scheduler V4 started.")
    logger.info("Signal tracking: DISABLED (dilakukan xau-collector)")
    logger.info("Jadwal: setiap hari %02d:%02d WIB", SEND_HOUR, SEND_MINUTE)

    await loop_winrate(bot)


# ============================================================
# ENTRY
# ============================================================

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("Scheduler stop.")