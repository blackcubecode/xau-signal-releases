import io
import math
from datetime import datetime

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.collections import LineCollection, PatchCollection
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle


# ============================================================
# DEFAULTS
# ============================================================

CHART_CANDLES = 55
POINT_SIZE = 0.01  # XAUUSD: 1 poin = 0.01 (10 poin = 0.10 USD)


# ============================================================
# THEMES
# ============================================================

THEMES = {
    "dark": dict(
        BG="#02070d", PANEL="#050c13", GRID="#12202b", BOX="#061019",
        WHITE="#f2f4f7", MUTED="#7f8b98",
        GREEN="#00e676", RED="#ff3b3b",
        CYAN="#00d9ff", YELLOW="#ffc83d", PURPLE="#a66cff",
    ),
    "light": dict(
        BG="#ffffff", PANEL="#f6f8fa", GRID="#dde3ea", BOX="#ffffff",
        WHITE="#0b1620", MUTED="#5c6875",
        GREEN="#0a9e5a", RED="#d62839",
        CYAN="#0088b3", YELLOW="#c48a00", PURPLE="#7a45d6",
    ),
}


# ============================================================
# HELPERS
# ============================================================

def fmt_price(value):
    try:
        return f"{float(value):.2f}"
    except Exception:
        return "-"


def find_column(df, names):
    lower_map = {str(c).lower(): c for c in df.columns}
    for name in names:
        if name.lower() in lower_map:
            return lower_map[name.lower()]
    return None


def to_points(distance):
    return abs(distance) / POINT_SIZE


# ============================================================
# INDICATORS
# ============================================================

def calc_ema(series, period):
    return series.ewm(span=period, adjust=False).mean()


def calc_rsi(series, period=14):
    delta = series.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1 / period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1 / period, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    rsi = 100 - (100 / (1 + rs))
    return rsi.fillna(50)


def calc_atr(data, period=14):
    prev_close = data["close"].shift(1)
    tr = pd.concat(
        [
            data["high"] - data["low"],
            (data["high"] - prev_close).abs(),
            (data["low"] - prev_close).abs(),
        ],
        axis=1,
    ).max(axis=1)
    return tr.ewm(alpha=1 / period, adjust=False).mean()


def ensure_indicators(data):
    """Tambahkan kolom indikator jika belum tersedia."""
    if find_column(data, ["ema20", "ema_20"]) is None:
        data["ema20"] = calc_ema(data["close"], 20)
    if find_column(data, ["ema50", "ema_50"]) is None:
        data["ema50"] = calc_ema(data["close"], 50)
    if find_column(data, ["ema200", "ema_200"]) is None:
        data["ema200"] = calc_ema(data["close"], 200)
    if find_column(data, ["rsi14", "rsi"]) is None:
        data["rsi14"] = calc_rsi(data["close"], 14)
    if find_column(data, ["atr14", "atr"]) is None:
        data["atr14"] = calc_atr(data, 14)
    return data


# ============================================================
# PREPARE DATAFRAME
# ============================================================

def prepare_dataframe(df, candles=CHART_CANDLES, auto_indicators=True):
    data = df.copy()

    datetime_col = None
    for col in ["datetime", "Datetime", "date", "Date", "time", "Time",
                "timestamp", "Timestamp"]:
        if col in data.columns:
            datetime_col = col
            break

    if datetime_col is not None:
        data[datetime_col] = pd.to_datetime(data[datetime_col], errors="coerce")
        data = data.dropna(subset=[datetime_col])
        data.index = data[datetime_col]
    elif not isinstance(data.index, pd.DatetimeIndex):
        try:
            data.index = pd.to_datetime(data.index, errors="coerce")
        except Exception:
            pass

    rename_map = {}
    for col in data.columns:
        lower = str(col).lower()
        if lower in ("open", "high", "low", "close"):
            rename_map[col] = lower
        elif lower in ("volume", "tick_volume", "tickvol", "vol"):
            rename_map[col] = "volume"
    data = data.rename(columns=rename_map)
    data = data.loc[:, ~data.columns.duplicated()]

    required = ["open", "high", "low", "close"]
    for col in required:
        if col not in data.columns:
            raise ValueError(f"Kolom '{col}' tidak ditemukan.")
        data[col] = pd.to_numeric(data[col], errors="coerce")

    if "volume" in data.columns:
        data["volume"] = pd.to_numeric(data["volume"], errors="coerce")

    data = data.dropna(subset=required).sort_index()
    data = data[~data.index.duplicated(keep="last")]

    # Hitung indikator pada data penuh sebelum dipotong
    if auto_indicators:
        data = ensure_indicators(data)

    data = data.tail(candles)

    if len(data) < 10:
        raise ValueError("Data M15 terlalu sedikit untuk membuat chart.")

    return data


# ============================================================
# ANALYSIS HELPERS
# ============================================================

def validate_levels(signal, entry, sl, tps):
    """Return list peringatan jika urutan level tidak sesuai arah sinyal."""
    warnings = []
    tp1, tp2, tp3 = tps

    if signal == "BUY":
        if not sl < entry:
            warnings.append("SL harus di bawah ENTRY (BUY)")
        if not entry < tp1 <= tp2 <= tp3:
            warnings.append("TP harus naik di atas ENTRY (BUY)")
    elif signal == "SELL":
        if not sl > entry:
            warnings.append("SL harus di atas ENTRY (SELL)")
        if not entry > tp1 >= tp2 >= tp3:
            warnings.append("TP harus turun di bawah ENTRY (SELL)")
    return warnings


def risk_reward(entry, sl, tps):
    risk = abs(entry - sl)
    if risk <= 0:
        return [None, None, None]
    return [abs(tp - entry) / risk for tp in tps]


def detect_swings(data, left=3, right=3):
    """Deteksi swing high / low sederhana (fractal)."""
    highs, lows = [], []
    h = data["high"].values
    l = data["low"].values
    n = len(data)
    for i in range(left, n - right):
        if h[i] == max(h[i - left:i + right + 1]):
            highs.append((i, h[i]))
        if l[i] == min(l[i - left:i + right + 1]):
            lows.append((i, l[i]))
    return highs, lows


def detect_sr_levels(data, max_levels=3, tolerance_atr=0.6):
    """
    Cari zona support/resistance dari cluster swing point.
    Return list (level, touches, kind) - kind: 'R' atau 'S'.
    """
    highs, lows = detect_swings(data, 3, 3)
    last = float(data["close"].iloc[-1])

    atr_col = find_column(data, ["atr14", "atr"])
    if atr_col is not None and not np.isnan(data[atr_col].iloc[-1]):
        tol = float(data[atr_col].iloc[-1]) * tolerance_atr
    else:
        tol = float((data["high"] - data["low"]).mean()) * tolerance_atr
    tol = max(tol, 1e-6)

    points = sorted([p for _, p in highs] + [p for _, p in lows])
    clusters = []
    for p in points:
        if clusters and abs(p - np.mean(clusters[-1])) <= tol:
            clusters[-1].append(p)
        else:
            clusters.append([p])

    levels = [(float(np.mean(c)), len(c)) for c in clusters if len(c) >= 2]
    levels.sort(key=lambda x: -x[1])
    levels = levels[:max_levels]

    return [(lvl, t, "R" if lvl > last else "S") for lvl, t in levels], tol


def spread_labels(prices, min_gap):
    """
    Geser posisi label agar tidak bertumpuk.
    prices: dict {key: price}. Return dict {key: y_label}.
    """
    items = sorted(prices.items(), key=lambda kv: -kv[1])
    ys = [p for _, p in items]

    for i in range(1, len(ys)):
        if ys[i - 1] - ys[i] < min_gap:
            ys[i] = ys[i - 1] - min_gap

    # Pusatkan kembali blok yang terdorong agar tidak menyimpang jauh
    shift = np.mean([p for _, p in items]) - np.mean(ys)
    ys = [y + shift for y in ys]
    for i in range(1, len(ys)):
        if ys[i - 1] - ys[i] < min_gap:
            ys[i] = ys[i - 1] - min_gap

    return {k: y for (k, _), y in zip(items, ys)}


# ============================================================
# GENERATE SIGNAL CHART
# ============================================================

def generate_signal_chart(
    dataframe=None,
    signal=None,
    entry=None,
    sl=None,
    tp1=None,
    tp2=None,
    tp3=None,
    confidence=None,
    structure=None,
    df=None,
    # ---------------- opsi baru ----------------
    symbol="XAUUSD",
    symbol_name="GOLD / US DOLLAR",
    timeframe="M15",
    brand="BLACK CUBE CODE",
    candles=CHART_CANDLES,
    theme="dark",
    dpi=170,
    show_volume=True,
    show_sr=True,
    show_swings=True,
    show_rr=True,
    show_current_price=True,
    show_timestamp=True,
    strict=False,
):
    """
    Generate premium signal chart.

    strict=True  -> raise ValueError jika urutan SL/Entry/TP tidak valid.
    strict=False -> tetap digambar, tetapi muncul tanda peringatan di chart.
    """

    if dataframe is None:
        dataframe = df
    if dataframe is None:
        raise ValueError("Dataframe M15 tidak diberikan.")

    T = THEMES.get(theme, THEMES["dark"])
    BG, PANEL, GRID, BOX = T["BG"], T["PANEL"], T["GRID"], T["BOX"]
    WHITE, MUTED = T["WHITE"], T["MUTED"]
    GREEN, RED = T["GREEN"], T["RED"]
    CYAN, YELLOW, PURPLE = T["CYAN"], T["YELLOW"], T["PURPLE"]

    data = prepare_dataframe(dataframe, candles=candles)
    n = len(data)

    # ---------------- signal ----------------
    signal = str(signal or "WAIT").upper()
    signal_color = {"BUY": GREEN, "SELL": RED}.get(signal, MUTED)

    try:
        entry = float(entry)
        sl = float(sl)
        tp1 = float(tp1)
        tp2 = float(tp2)
        tp3 = float(tp3)
    except Exception as exc:
        raise ValueError("Entry / SL / TP tidak valid.") from exc

    tps = [tp1, tp2, tp3]
    level_warnings = validate_levels(signal, entry, sl, tps)
    if level_warnings and strict:
        raise ValueError("; ".join(level_warnings))

    rr = risk_reward(entry, sl, tps)
    last_close = float(data["close"].iloc[-1])

    # ---------------- layout ----------------
    has_volume = (
        show_volume
        and "volume" in data.columns
        and data["volume"].fillna(0).sum() > 0
    )

    fig = plt.figure(figsize=(16, 10), facecolor=BG)
    gs = fig.add_gridspec(
        100, 1, left=0.055, right=0.925, top=0.905, bottom=0.095, hspace=0
    )

    if has_volume:
        ax = fig.add_subplot(gs[4:66, 0])
        ax_vol = fig.add_subplot(gs[66:77, 0], sharex=ax)
    else:
        ax = fig.add_subplot(gs[4:77, 0])
        ax_vol = None
    ax_rsi = fig.add_subplot(gs[80:94, 0], sharex=ax)

    for a in (ax, ax_rsi, ax_vol):
        if a is not None:
            a.set_facecolor(PANEL)

    x = np.arange(n)

    # ========================================================
    # CANDLESTICKS (collection)
    # ========================================================
    opens = data["open"].values.astype(float)
    highs_ = data["high"].values.astype(float)
    lows_ = data["low"].values.astype(float)
    closes = data["close"].values.astype(float)
    up = closes >= opens

    wick_segments = [[(i, lows_[i]), (i, highs_[i])] for i in range(n)]
    wick_colors = [GREEN if u else RED for u in up]
    ax.add_collection(
        LineCollection(wick_segments, colors=wick_colors, linewidths=1.7,
                       capstyle="round", zorder=6)
    )

    candle_width = 0.62
    body_patches, body_colors = [], []
    for i in range(n):
        body_h = abs(closes[i] - opens[i])
        body_b = min(opens[i], closes[i])
        if body_h < 0.025:
            body_h = 0.025
            body_b = (opens[i] + closes[i]) / 2 - body_h / 2
        body_patches.append(Rectangle((i - candle_width / 2, body_b),
                                      candle_width, body_h))
        body_colors.append(GREEN if up[i] else RED)
    ax.add_collection(
        PatchCollection(body_patches, facecolors=body_colors,
                        edgecolors=body_colors, linewidths=0.8, zorder=7)
    )

    # ========================================================
    # EMA
    # ========================================================
    ema_specs = [
        (["ema20", "ema_20"], CYAN, 2.3, "EMA 20"),
        (["ema50", "ema_50"], YELLOW, 2.2, "EMA 50"),
        (["ema200", "ema_200"], PURPLE, 2.0, "EMA 200"),
    ]
    legend_handles = []
    for names, color, lw, label in ema_specs:
        col = find_column(data, names)
        if col is not None:
            ax.plot(x, data[col].astype(float).values, color=color,
                    linewidth=lw, zorder=8)
            legend_handles.append(Line2D([0], [0], color=color,
                                         linewidth=lw + 0.1, label=label))

    # ========================================================
    # PRICE RANGE
    # ========================================================
    all_levels = [float(data["high"].max()), float(data["low"].min()),
                  entry, sl, tp1, tp2, tp3]
    highest, lowest = max(all_levels), min(all_levels)
    price_range = highest - lowest
    if price_range <= 0:
        price_range = 1.0
    pad = price_range * 0.07
    y_lo, y_hi = lowest - pad, highest + pad
    ax.set_ylim(y_lo, y_hi)
    ax.set_xlim(-0.5, n + 3.5)

    # ========================================================
    # SUPPORT / RESISTANCE ZONES
    # ========================================================
    if show_sr:
        try:
            sr_levels, tol = detect_sr_levels(data)
            for lvl, touches, kind in sr_levels:
                if not (y_lo < lvl < y_hi):
                    continue
                col = RED if kind == "R" else GREEN
                ax.axhspan(lvl - tol * 0.25, lvl + tol * 0.25,
                           color=col, alpha=0.08, zorder=1)
                ax.text(0.5, lvl, f" {kind}  x{touches}", color=col,
                        fontsize=8, alpha=0.85, va="bottom", zorder=3)
        except Exception:
            pass

    # ========================================================
    # SWING MARKERS
    # ========================================================
    if show_swings:
        try:
            sh, sl_pts = detect_swings(data, 3, 3)
            off = price_range * 0.012
            if sh:
                ax.scatter([i for i, _ in sh], [p + off for _, p in sh],
                           marker="v", s=22, color=MUTED, alpha=0.75, zorder=9)
            if sl_pts:
                ax.scatter([i for i, _ in sl_pts], [p - off for _, p in sl_pts],
                           marker="^", s=22, color=MUTED, alpha=0.75, zorder=9)
        except Exception:
            pass

    # ========================================================
    # PROFIT / RISK ZONE
    # ========================================================
    zone_start = max(0, n - 13)
    zone_x = [zone_start, n + 2.5]

    if signal == "BUY":
        ax.fill_between(zone_x, entry, tp3, color=GREEN, alpha=0.07, zorder=1)
        ax.fill_between(zone_x, sl, entry, color=RED, alpha=0.10, zorder=1)
    elif signal == "SELL":
        ax.fill_between(zone_x, tp3, entry, color=GREEN, alpha=0.07, zorder=1)
        ax.fill_between(zone_x, entry, sl, color=RED, alpha=0.10, zorder=1)

    # Garis TP1/TP2 di dalam zona profit (gradasi visual)
    for lvl, a in ((tp1, 0.10), (tp2, 0.08)):
        if signal in ("BUY", "SELL"):
            ax.fill_between(zone_x, entry, lvl, color=GREEN, alpha=a, zorder=1)

    # ========================================================
    # LEVEL LINES
    # ========================================================
    ax.axhline(entry, color=WHITE, linestyle="--", linewidth=1.6,
               alpha=0.95, zorder=4)
    ax.axhline(sl, color=RED, linestyle="--", linewidth=1.6,
               alpha=0.95, zorder=4)
    for level in tps:
        ax.axhline(level, color=GREEN, linestyle="--", linewidth=1.5,
                   alpha=0.95, zorder=4)

    # ========================================================
    # CURRENT PRICE LINE
    # ========================================================
    if show_current_price:
        ax.axhline(last_close, color=CYAN, linestyle=":", linewidth=1.1,
                   alpha=0.85, zorder=5)
        ax.scatter([n - 1], [last_close], s=34, color=CYAN,
                   edgecolor=BG, linewidth=1.0, zorder=12)

    # ========================================================
    # RIGHT PRICE LABELS (anti-overlap)
    # ========================================================
    label_prices = {
        "TP3": tp3, "TP2": tp2, "TP1": tp1,
        "ENTRY": entry, "STOP LOSS": sl,
    }
    label_colors = {
        "TP3": GREEN, "TP2": GREEN, "TP1": GREEN,
        "ENTRY": WHITE, "STOP LOSS": RED,
    }
    if show_current_price:
        label_prices["PRICE"] = last_close
        label_colors["PRICE"] = CYAN

    # 1 label ~ 2.6% dari tinggi sumbu
    min_gap = (y_hi - y_lo) * 0.032
    label_y = spread_labels(label_prices, min_gap)

    for key, price in label_prices.items():
        color = label_colors[key]
        ly = label_y[key]
        text = f"{key}  {fmt_price(price)}"
        ax.annotate(
            text,
            xy=(1.0, price),
            xycoords=ax.get_yaxis_transform(),
            xytext=(1.012, ly),
            textcoords=ax.get_yaxis_transform(),
            ha="left", va="center",
            fontsize=10, fontweight="bold", color=WHITE,
            bbox=dict(boxstyle="round,pad=0.27", facecolor=BG,
                      edgecolor=color, linewidth=1.4),
            arrowprops=dict(arrowstyle="-", color=color, linewidth=1.0,
                            shrinkA=0, shrinkB=0),
            annotation_clip=False,
            zorder=30,
        )

    # ========================================================
    # SIGNAL ARROW (candle terakhir)
    # ========================================================
    if signal in ("BUY", "SELL"):
        arrow_off = price_range * 0.06
        if signal == "BUY":
            y_tip = lows_[-1] - price_range * 0.01
            y_txt = y_tip - arrow_off
        else:
            y_tip = highs_[-1] + price_range * 0.01
            y_txt = y_tip + arrow_off
        ax.annotate(
            signal,
            xy=(n - 1, y_tip),
            xytext=(n - 1, y_txt),
            ha="center", va="center",
            fontsize=10, fontweight="bold", color=BG,
            bbox=dict(boxstyle="round,pad=0.3", facecolor=signal_color,
                      edgecolor=signal_color),
            arrowprops=dict(arrowstyle="-|>", color=signal_color, linewidth=1.8),
            zorder=25,
        )

    # ========================================================
    # INFO BOX
    # ========================================================
    setup_text = str(structure or "UNKNOWN")
    conf_text = f"{confidence}%" if confidence is not None else "-"

    lines = [
        f"SIGNAL    {signal}",
        f"ENTRY     {fmt_price(entry)}",
        f"SL        {fmt_price(sl)}  ({to_points(entry - sl):.0f} pts)",
        f"TP1       {fmt_price(tp1)}  ({to_points(tp1 - entry):.0f} pts)",
        f"TP2       {fmt_price(tp2)}  ({to_points(tp2 - entry):.0f} pts)",
        f"TP3       {fmt_price(tp3)}  ({to_points(tp3 - entry):.0f} pts)",
        f"CONF.     {conf_text}",
        f"SETUP     {setup_text}",
    ]
    if show_rr and rr[0] is not None:
        lines.insert(
            6, f"R:R       1:{rr[0]:.1f} | 1:{rr[1]:.1f} | 1:{rr[2]:.1f}"
        )

    ax.text(
        0.015, 0.955, "\n".join(lines),
        transform=ax.transAxes, ha="left", va="top",
        color=WHITE, fontsize=10, family="monospace", linespacing=1.45,
        bbox=dict(boxstyle="round,pad=0.65", facecolor=BOX,
                  edgecolor=signal_color, linewidth=1.7, alpha=0.98),
        zorder=40,
    )

    # Floating P/L
    if show_current_price and signal in ("BUY", "SELL"):
        pnl = (last_close - entry) if signal == "BUY" else (entry - last_close)
        pnl_color = GREEN if pnl >= 0 else RED
        ax.text(
            0.985, 0.955,
            f"FLOATING  {pnl / POINT_SIZE:+.0f} pts",
            transform=ax.transAxes, ha="right", va="top",
            color=pnl_color, fontsize=10.5, fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.4", facecolor=BOX,
                      edgecolor=pnl_color, linewidth=1.3),
            zorder=40,
        )

    # Warning level tidak valid
    if level_warnings:
        ax.text(
            0.5, 0.5, "CHECK LEVELS\n" + "\n".join(level_warnings),
            transform=ax.transAxes, ha="center", va="center",
            color=YELLOW, fontsize=13, fontweight="bold", alpha=0.9,
            bbox=dict(boxstyle="round,pad=0.6", facecolor=BG,
                      edgecolor=YELLOW, linewidth=1.5),
            zorder=50,
        )

    # ========================================================
    # LEGEND
    # ========================================================
    if legend_handles:
        legend = ax.legend(
            handles=legend_handles, loc="upper left",
            bbox_to_anchor=(0.005, 1.025), frameon=False,
            ncol=3, fontsize=9.5,
        )
        for text in legend.get_texts():
            text.set_color(WHITE)

    # ========================================================
    # WATERMARK
    # ========================================================
    ax.text(
        0.5, 0.5, brand, transform=ax.transAxes, ha="center", va="center",
        fontsize=46, fontweight="bold", color=WHITE, alpha=0.035,
        rotation=18, zorder=2,
    )

    # ========================================================
    # GRID / AXES
    # ========================================================
    for a in (ax, ax_rsi, ax_vol):
        if a is not None:
            a.grid(True, color=GRID, linewidth=0.65, alpha=0.8)
            for spine in a.spines.values():
                spine.set_color(GRID)
                spine.set_linewidth(1)

    ax.tick_params(axis="y", colors=MUTED, labelsize=9)
    ax.tick_params(axis="x", colors=MUTED)
    ax.set_ylabel("PRICE", color=MUTED, fontsize=9)
    plt.setp(ax.get_xticklabels(), visible=False)

    # ========================================================
    # VOLUME
    # ========================================================
    if ax_vol is not None:
        vol = data["volume"].fillna(0).values.astype(float)
        ax_vol.bar(x, vol, width=0.62,
                   color=[GREEN if u else RED for u in up], alpha=0.65, zorder=3)
        ax_vol.set_ylabel("VOL", color=MUTED, fontsize=8)
        ax_vol.tick_params(axis="y", colors=MUTED, labelsize=7)
        ax_vol.set_ylim(0, max(vol.max() * 1.15, 1))
        plt.setp(ax_vol.get_xticklabels(), visible=False)

    # ========================================================
    # RSI
    # ========================================================
    rsi_col = find_column(data, ["rsi14", "rsi"])

    if rsi_col is not None:
        rsi = data[rsi_col].astype(float)
        ax_rsi.axhspan(70, 100, color=RED, alpha=0.06, zorder=1)
        ax_rsi.axhspan(0, 30, color=GREEN, alpha=0.06, zorder=1)
        ax_rsi.plot(x, rsi.values, color=PURPLE, linewidth=2.0, zorder=5)
        ax_rsi.axhline(70, color=RED, linestyle="--", linewidth=1.2)
        ax_rsi.axhline(50, color=MUTED, linestyle="--", linewidth=0.7, alpha=0.45)
        ax_rsi.axhline(30, color=GREEN, linestyle="--", linewidth=1.2)
        ax_rsi.set_ylim(0, 100)
        ax_rsi.set_ylabel("RSI (14)", color=MUTED, fontsize=9)
        ax_rsi.tick_params(axis="y", colors=MUTED, labelsize=8)
        ax_rsi.tick_params(axis="x", colors=MUTED, labelsize=8)

        current_rsi = float(rsi.iloc[-1])
        rsi_state = ("OVERBOUGHT" if current_rsi >= 70
                     else "OVERSOLD" if current_rsi <= 30 else "NEUTRAL")
        ax_rsi.text(
            0.01, 0.84, f"RSI (14)  {current_rsi:.1f}  {rsi_state}",
            transform=ax_rsi.transAxes, color=WHITE, fontsize=9.5,
            fontweight="bold", ha="left", va="top",
        )
        ax_rsi.scatter([n - 1], [current_rsi], s=26, color=PURPLE,
                       edgecolor=BG, zorder=6)

        for v in (70, 50, 30):
            ax_rsi.text(1.005, v, str(v), transform=ax_rsi.get_yaxis_transform(),
                        color=MUTED, fontsize=8, va="center")
    else:
        ax_rsi.axis("off")

    # ========================================================
    # TIME LABELS
    # ========================================================
    try:
        step = max(1, math.ceil(n / 8))
        positions = list(range(0, n, step))
        labels = [data.index[p].strftime("%d %b\n%H:%M") for p in positions]
        ax_rsi.set_xticks(positions)
        ax_rsi.set_xticklabels(labels, color=MUTED, fontsize=8)
    except Exception:
        pass

    # ========================================================
    # HEADER
    # ========================================================
    fig.text(0.055, 0.965, brand, color=WHITE, fontsize=25,
             fontweight="bold", ha="left", va="center")
    fig.text(0.055, 0.935, f"{symbol}  |  {timeframe}  |  {signal} SIGNAL",
             color=signal_color, fontsize=12.5, fontweight="bold",
             ha="left", va="center")

    fig.text(0.885, 0.965, symbol, color=WHITE, fontsize=22,
             fontweight="bold", ha="right", va="center")
    fig.text(0.885, 0.938, symbol_name, color=MUTED, fontsize=9,
             ha="right", va="center")
    fig.text(0.94, 0.963, timeframe, color=WHITE, fontsize=12,
             fontweight="bold", ha="center", va="center",
             bbox=dict(boxstyle="round,pad=0.4", facecolor=BG,
                       edgecolor=MUTED, linewidth=1))

    # fig.lines.append() sudah deprecated -> gunakan add_artist
    fig.add_artist(Line2D([0.03, 0.97], [0.91, 0.91],
                          transform=fig.transFigure, color=GRID, linewidth=1))

    # ========================================================
    # FOOTER
    # ========================================================
    fig.text(0.055, 0.035, brand, color=WHITE, fontsize=10.5,
             fontweight="bold", ha="left")
    fig.text(0.33, 0.035, "|", color=MUTED, fontsize=11, ha="center")
    fig.text(0.39, 0.035, f"{symbol} {timeframe}  |  {signal} SIGNAL",
             color=MUTED, fontsize=9.5, ha="center")

    if show_timestamp:
        try:
            last_dt = data.index[-1].strftime("%d %b %Y  %H:%M")
        except Exception:
            last_dt = datetime.utcnow().strftime("%d %b %Y  %H:%M")
        fig.text(0.62, 0.035, f"LAST CANDLE  {last_dt}", color=MUTED,
                 fontsize=9, ha="center")

    fig.text(0.92, 0.035, "TRADE WITH DISCIPLINE", color=signal_color,
             fontsize=9.5, fontweight="bold", ha="right")

    # ========================================================
    # SAVE
    # ========================================================
    buffer = io.BytesIO()
    fig.savefig(buffer, format="png", dpi=dpi, facecolor=BG,
                bbox_inches="tight", pad_inches=0.12)
    plt.close(fig)
    buffer.seek(0)
    buffer.name = f"{brand.replace(' ', '_')}_{symbol}_{timeframe}.png"
    return buffer


# ============================================================
# SELF TEST
# ============================================================

if __name__ == "__main__":
    rng = np.random.default_rng(7)
    idx = pd.date_range("2026-09-14 00:00", periods=400, freq="15min")
    close = 3650 + np.cumsum(rng.normal(0.05, 1.6, len(idx)))
    open_ = np.concatenate([[close[0]], close[:-1]])
    high = np.maximum(open_, close) + rng.uniform(0.2, 1.8, len(idx))
    low = np.minimum(open_, close) - rng.uniform(0.2, 1.8, len(idx))
    sample_df = pd.DataFrame(
        {"open": open_, "high": high, "low": low, "close": close,
         "volume": rng.integers(200, 2000, len(idx))},
        index=idx,
    )
    px = float(sample_df["close"].iloc[-1])
    buf = generate_signal_chart(
        dataframe=sample_df, signal="BUY",
        entry=px, sl=px - 6, tp1=px + 5, tp2=px + 10, tp3=px + 16,
        confidence=82, structure="BOS + Pullback EMA20",
    )
    with open(buf.name, "wb") as f:
        f.write(buf.getvalue())
    print(f"Saved {buf.name}")


