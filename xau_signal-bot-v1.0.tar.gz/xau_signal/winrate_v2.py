"""
BLACK CUBE CODE - Daily Report V4

Fungsi:
- Statistik sinyal dalam 24 jam terakhir
- Reset tiap hari (rolling window)
- Format report simpel untuk Telegram
- Unicode escape untuk emoji (RULE)
"""

import logging
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytz

logger = logging.getLogger(__name__)

from paths import DB_PATH
WIB = pytz.timezone("Asia/Jakarta")


def _parse_time(value):
    if not value:
        return None
    try:
        value = str(value).strip()
        if value.endswith(" WIB"):
            value = value[:-4].strip()
            dt = datetime.strptime(value, "%Y-%m-%d %H:%M:%S")
            return WIB.localize(dt)
        try:
            dt = datetime.strptime(value, "%Y-%m-%d %H:%M:%S")
            return WIB.localize(dt)
        except ValueError:
            pass
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            return WIB.localize(dt)
        return dt.astimezone(WIB)
    except Exception:
        return None


def get_stats(hours=24):
    """
    Statistik sinyal dalam N jam terakhir.

    Window menggunakan SERVER TIME (UTC).
    Tampilan tetap WIB.
    """

    if not DB_PATH.exists():
        logger.error("Database tidak ada: %s", DB_PATH)
        return None

    try:
        conn = sqlite3.connect(str(DB_PATH))
        conn.row_factory = sqlite3.Row
    except Exception as e:
        logger.error("Koneksi gagal: %s", e)
        return None

    try:
        # Window pakai UTC (server time)
        now_utc = datetime.now(timezone.utc)
        cutoff_utc = now_utc - timedelta(hours=hours)

        # Untuk tampilan
        now_wib = now_utc.astimezone(WIB)

        logger.info(
            "Window UTC: %s s/d %s",
            cutoff_utc.strftime("%Y-%m-%d %H:%M UTC"),
            now_utc.strftime("%Y-%m-%d %H:%M UTC"),
        )

        rows = conn.execute("""
            SELECT id, signal_id, signal, confidence, structure,
                   sent_at, status, result,
                   tp1_hit_at, tp2_hit_at, tp3_hit_at, sl_hit_at
            FROM signals
            ORDER BY id DESC
        """).fetchall()

        signals = []
        for row in rows:
            # Parse sent_at (WIB) ? convert ke UTC
            sent_wib = _parse_time(row["sent_at"])
            if sent_wib is None:
                continue

            sent_utc = sent_wib.astimezone(timezone.utc)

            # Filter: hanya yang dalam window UTC
            if sent_utc < cutoff_utc:
                continue

            signals.append(row)

        total = len(signals)
        wins = sum(1 for r in signals if r["status"] == "WIN")
        losses = sum(1 for r in signals if r["status"] == "LOSS")
        pending = sum(1 for r in signals if r["status"] == "PENDING")
        expired = sum(1 for r in signals if r["status"] == "EXPIRED")
        closed = wins + losses

        tp_hits = 0
        sl_hits = 0
        for r in signals:
            if r["tp1_hit_at"] or r["result"] == "TP1_HIT":
                tp_hits += 1
            elif r["tp2_hit_at"] or r["result"] == "TP2_HIT":
                tp_hits += 1
            elif r["tp3_hit_at"] or r["result"] == "TP3_HIT":
                tp_hits += 1
            if r["sl_hit_at"] or r["result"] == "SL_HIT":
                sl_hits += 1

        winrate = (wins / closed * 100) if closed > 0 else 0

        return {
            "total": total, "wins": wins, "losses": losses,
            "pending": pending, "expired": expired, "closed": closed,
            "winrate": round(winrate, 1),
            "tp_hits": tp_hits, "sl_hits": sl_hits,
            "period_hours": hours, "now_wib": now_wib,
            "now_utc": now_utc, "cutoff_utc": cutoff_utc,
        }
    except Exception as e:
        logger.exception("Error get_stats: %s", e)
        return None
    finally:
        conn.close()


def build_report_message():
    """
    Format report harian � V5.
    Tanggal = trading day yang baru selesai (kemarin kalau dikirim pagi).
    RULE: pakai Unicode escape untuk emoji.
    """

    stats = get_stats(hours=24)

    if stats is None:
        return (
            "\U0001F4CA DAILY REPORT\n\n"
            "Gagal memuat data statistik."
        )

    now_wib = stats["now_wib"]

    # Kalau dikirim pagi (< 12:00), report = trading day kemarin
    if now_wib.hour < 12:
        from datetime import timedelta as _td
        report_date = now_wib - _td(days=1)
    else:
        report_date = now_wib

    date_str = report_date.strftime("%d %b %Y")
    time_str = now_wib.strftime("%H:%M WIB")

    total = stats["total"]
    closed = stats["closed"]
    wr = stats["winrate"]
    wins = stats["wins"]
    losses = stats["losses"]
    tp_hits = stats["tp_hits"]
    sl_hits = stats["sl_hits"]

    # Winrate display
    if closed == 0:
        winrate_display = "N/A"
    else:
        winrate_display = f"{wr:.1f}%"

    # Status
    if closed == 0:
        status_emoji = "\u23F3"
        status_label = "Menunggu data"
    elif wr >= 70:
        status_emoji = "\U0001F389"
        status_label = "Sangat baik"
    elif wr >= 50:
        status_emoji = "\U0001F44D"
        status_label = "Cukup baik"
    else:
        status_emoji = "\U0001F4AA"
        status_label = "Perlu evaluasi"

    lines = [
        "\U0001F4CA DAILY REPORT",
        f"\U0001F4C5 {date_str}",
        f"\U0001F550 {time_str}",
        "",
        "\U0001F4C8 PERFORMANCE",
        "",
        f"Total Sinyal : {total}",
        f"Winrate      : {winrate_display}",
        "",
        f"\u2705 Win  : {wins}",
        f"\u274C Loss : {losses}",
        "",
        "\U0001F3AF TARGET STATS",
        "",
        f"\U0001F947 TP Hit : {tp_hits}",
        f"\u26D4 SL Hit : {sl_hits}",
        "",
        f"{status_emoji} Status : {status_label}",
        "",
        f"_Data trading day {date_str}_",
    ]

    return "\n".join(lines)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s | %(levelname)s | %(message)s")
    print(build_report_message())
