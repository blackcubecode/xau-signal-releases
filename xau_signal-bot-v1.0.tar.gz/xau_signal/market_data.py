import logging
import requests
import pandas as pd

logger = logging.getLogger(__name__)

BASE_URL = "https://biquote.io/api/XAUUSD/ohlc"
LIMIT = 200
TIMEOUT = 15


def get_ohlc(interval):
    try:
        logger.info("Request BiQuote: XAUUSD %s...", interval)

        response = requests.get(
            BASE_URL,
            params={
                "interval": interval,
                "limit": LIMIT
            },
            timeout=TIMEOUT
        )

        response.raise_for_status()
        result = response.json()

        bars = result.get("bars", [])

        if not bars:
            logger.warning("%s: data kosong", interval)
            return pd.DataFrame()

        df = pd.DataFrame(bars)

        # Pastikan openTime ada
        if "openTime" not in df.columns:
            logger.error("%s: kolom openTime tidak ditemukan", interval)
            return pd.DataFrame()

        # Simpan status candle sebelum kolom lainnya diproses
        if "isOpen" in df.columns:
            df["isOpen"] = df["isOpen"].fillna(False).astype(bool)

        # Parse waktu ISO dari BiQuote
        df["datetime"] = pd.to_datetime(
            df["openTime"],
            format="ISO8601",
            utc=True,
            errors="coerce"
        )

        # Validasi waktu
        if df["datetime"].isna().all():
            logger.error(
                "%s: semua openTime gagal diparse. Contoh: %s",
                interval,
                df["openTime"].iloc[0]
            )
            return pd.DataFrame()

        # Harga
        for col in ["open", "high", "low", "close"]:
            df[col] = pd.to_numeric(
                df[col],
                errors="coerce"
            )

        # Volume
        if "tickVolume" in df.columns:
            df["volume"] = pd.to_numeric(
                df["tickVolume"],
                errors="coerce"
            )
        elif "volume" in df.columns:
            df["volume"] = pd.to_numeric(
                df["volume"],
                errors="coerce"
            )
        else:
            df["volume"] = 0

        # Buang candle yang masih berjalan
        if "isOpen" in df.columns:
            df = df[df["isOpen"] == False].copy()

        # Buang data tidak valid
        df = df.dropna(
            subset=[
                "datetime",
                "open",
                "high",
                "low",
                "close"
            ]
        )

        # Pilih kolom yang dibutuhkan
        df = df[
            [
                "datetime",
                "open",
                "high",
                "low",
                "close",
                "volume"
            ]
        ]

        # Urutkan candle lama -> terbaru
        df = df.sort_values(
            "datetime"
        ).reset_index(drop=True)

        logger.info(
            "%s: %d closed candles | terbaru=%s",
            interval,
            len(df),
            df["datetime"].iloc[-1] if not df.empty else "NONE"
        )

        return df

    except requests.RequestException as e:
        logger.error(
            "BiQuote request error %s: %s",
            interval,
            e
        )
        return pd.DataFrame()

    except Exception as e:
        logger.exception(
            "Gagal memproses %s: %s",
            interval,
            e
        )
        return pd.DataFrame()


def get_market_data():
    logger.info("Mengambil market data dari BiQuote...")

    m5 = get_ohlc("5m")
    m15 = get_ohlc("15m")
    h1 = get_ohlc("1h")

    logger.info(
        "BiQuote data | M5=%d | M15=%d | H1=%d",
        len(m5),
        len(m15),
        len(h1)
    )

    return {
        "M5": m5,
        "M15": m15,
        "H1": h1
    }


# Compatibility aliases
def get_data():
    return get_market_data()


def fetch_market_data():
    return get_market_data()


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s"
    )

    data = get_market_data()

    for name, df in data.items():
        print("\n", "=" * 60)
        print(name)

        if df.empty:
            print("DATA KOSONG")
        else:
            print(df.tail(3).to_string(index=False))
