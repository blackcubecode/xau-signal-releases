"""Filter news high-impact USD dengan cache disk."""
import json
import logging
import requests
from datetime import datetime
from pathlib import Path
import pytz

logger = logging.getLogger(__name__)

NEWS_URL = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"
from paths import NEWS_CACHE_FILE as CACHE_FILE
CACHE_DURATION = 1800  # 30 menit

_cache = {"time": None, "events": []}


def _load_cache_disk():
    """Baca cache dari disk."""
    if CACHE_FILE.exists():
        try:
            data = json.loads(CACHE_FILE.read_text())
            return data
        except Exception as e:
            logger.warning("Gagal baca cache disk: %s", e)
    return None


def _save_cache_disk(events):
    """Simpan cache ke disk."""
    try:
        CACHE_FILE.write_text(json.dumps(events))
    except Exception as e:
        logger.warning("Gagal simpan cache: %s", e)


def _fetch_feed():
    """Fetch feed dengan retry & fallback ke cache."""
    now = datetime.now(pytz.UTC)

    # Cek memory cache
    if _cache["time"] and (now - _cache["time"]).total_seconds() < CACHE_DURATION:
        return _cache["events"]

    # Coba fetch
    try:
        r = requests.get(NEWS_URL, timeout=15, headers={"User-Agent": "Mozilla/5.0"})
        if r.status_code == 429:
            logger.warning("Rate limit 429, pakai cache disk")
            disk = _load_cache_disk()
            if disk:
                _cache["time"] = now
                _cache["events"] = disk
                return disk
            return []

        r.raise_for_status()
        # Validasi: pastikan response JSON, bukan HTML
        ctype = r.headers.get("content-type", "")
        if "json" not in ctype.lower():
            logger.warning("Response bukan JSON (%s), pakai cache disk", ctype)
            disk = _load_cache_disk()
            if disk:
                _cache["time"] = now
                _cache["events"] = disk
                return disk
            return []

        events = r.json()
        if not isinstance(events, list) or len(events) == 0:
            logger.warning("Response JSON kosong/bukan list")
            return []

        _cache["time"] = now
        _cache["events"] = events
        _save_cache_disk(events)
        logger.info("Feed OK, %d events", len(events))
        return events

    except Exception as e:
        logger.warning("Fetch gagal: %s, pakai cache disk", e)
        disk = _load_cache_disk()
        if disk:
            _cache["time"] = now
            _cache["events"] = disk
            return disk
        return []


def is_news_time(buffer_minutes=30):
    """Return (True, title) kalau dalam buffer menit dari news high-impact USD."""
    events = _fetch_feed()
    if not events:
        return False, None

    now = datetime.now(pytz.UTC)

    for ev in events:
        if ev.get("impact", "").lower() != "high":
            continue
        if ev.get("country", "").upper() != "USD":
            continue
        try:
            ev_time = datetime.fromisoformat(ev["date"].replace("Z", "+00:00"))
        except Exception:
            continue
        diff = abs((ev_time - now).total_seconds() / 60)
        if diff <= buffer_minutes:
            return True, ev["title"]

    return False, None
