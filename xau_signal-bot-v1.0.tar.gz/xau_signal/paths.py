"""Path configuration — semua path file disimpan relatif ke folder script ini."""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

# Env
ENV_FILE = BASE_DIR / ".env"

# Cache & state
NEWS_CACHE_FILE = BASE_DIR / "news_cache.json"
COOLDOWN_FILE = BASE_DIR / ".cooldown_state.json"
WEEKEND_FLAG_FILE = BASE_DIR / "weekend_flag.json"
MONDAY_FLAG_FILE = BASE_DIR / "monday_flag.json"
SENT_SIGNAL_FILE = BASE_DIR / "sent_signal.json"
NOTIFIED_CLOSED_FILE = BASE_DIR / "notified_closed.json"
QRIS_LAST_SENT_FILE = BASE_DIR / "qris_last_sent.json"

# Database
DB_PATH = BASE_DIR / "signals_history.db"

# Asset
QRIS_PATH = BASE_DIR / "qris.jpg"