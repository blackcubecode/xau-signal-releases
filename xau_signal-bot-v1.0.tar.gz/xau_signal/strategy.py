"""
BLACK CUBE CODE - XAUUSD Strategy V5

Engine sinyal baru � trend following yang simpel & robust.

Logic:
1. H1 + M15 align ? sinyal
2. H1 NEUTRAL + M15 jelas ? sinyal dengan penalti
3. SL: swing + 0.4 ATR (max 2.5 ATR)
4. TP: 3 level (1R/2R/3R)
5. Cooldown 90 menit + post-LOSS 120 menit
6. Frekuensi target: 2-5 sinyal/hari
"""

import json
import logging
from datetime import datetime
from pathlib import Path

import pytz

logger = logging.getLogger(__name__)

WIB = pytz.timezone("Asia/Jakarta")

from paths import COOLDOWN_FILE


# ============================================================
# CONFIG
# ============================================================
MIN_CONFIDENCE = 75
SL_ATR_BUFFER = 0.40
MIN_RR = 1.50
TP1_RR = 1.00
TP2_RR = 2.00
TP3_RR = 3.00
COOLDOWN_MINUTES = 90
POST_LOSS_COOLDOWN_MINUTES = 120
MIN_ATR = 0.80
NOISE_HOURS = list(range(3, 6)) + list(range(22, 24))
MIN_VOLUME_RATIO = 0.70


# ============================================================
# UTILITY
# ============================================================
def _safe(value, default=0.0):
    try:
        if value is None:
            return default
        v = float(value)
        if v != v:
            return default
        return v
    except (TypeError, ValueError):
        return default


def _trend(value):
    if not value:
        return "NEUTRAL"
    t = str(value).upper().strip()
    if t in ("BULLISH", "UP", "BUY"):
        return "BULLISH"
    if t in ("BEARISH", "DOWN", "SELL"):
        return "BEARISH"
    return "NEUTRAL"


def get_market_session():
    """
    Return (session_name, emoji, status) berdasarkan jam WIB.

    Sesi:
    - 05:00-07:00 : PRE-MARKET (prep)
    - 07:00-14:00 : ASIA (buka awal)
    - 14:00-19:00 : LONDON (aktif)
    - 19:00-04:00 : NEW YORK (volatil)
    - 04:00-05:00 : CLOSED (tutup)
    """
    jam = datetime.now(WIB).hour

    if 5 <= jam < 7:
        return ("PRE-MARKET", "\U0001F305", "Prep")
    elif 7 <= jam < 14:
        return ("ASIA", "\U0001F30F", "Buka awal")
    elif 14 <= jam < 19:
        return ("LONDON", "\U0001F1EC\U0001F1E7", "Aktif")
    elif 19 <= jam < 24:
        return ("NEW YORK", "\U0001F1FA\U0001F1F8", "Volatil")
    else:
        return ("CLOSED", "\U0001F319", "Tutup")


def _wait(price, reason):
    logger.debug("WAIT: %s | price=%s", reason, price)
    return {
        "signal": "WAIT",
        "confidence": 0,
        "entry": round(price, 2) if price > 0 else 0,
        "sl": 0, "tp1": 0, "tp2": 0, "tp3": 0,
        "risk": 0, "rr": "1:0",
        "structure": "NO_SIGNAL",
        "reasons": [reason],
    }


# ============================================================
# COOLDOWN
# ============================================================
def _load_cooldown_state():
    try:
        if COOLDOWN_FILE.exists():
            return json.loads(COOLDOWN_FILE.read_text(encoding="utf-8"))
    except Exception as e:
        logger.warning("Load cooldown gagal: %s", e)
    return {}


def _save_cooldown_state(state):
    try:
        COOLDOWN_FILE.write_text(
            json.dumps(state, indent=2),
            encoding="utf-8"
        )
    except Exception as e:
        logger.warning("Save cooldown gagal: %s", e)


def _check_cooldown():
    state = _load_cooldown_state()
    now = datetime.now(WIB)

    last_signal_at = state.get("last_signal_at")
    if last_signal_at:
        try:
            last_dt = datetime.fromisoformat(last_signal_at)
            if last_dt.tzinfo is None:
                last_dt = WIB.localize(last_dt)
            elapsed = (now - last_dt).total_seconds() / 60
            if elapsed < COOLDOWN_MINUTES:
                logger.info("Cooldown: %.0f menit tersisa",
                            COOLDOWN_MINUTES - elapsed)
                return True
        except Exception as e:
            logger.warning("Parse last_signal_at: %s", e)

    last_loss_at = state.get("last_loss_at")
    if last_loss_at:
        try:
            loss_dt = datetime.fromisoformat(last_loss_at)
            if loss_dt.tzinfo is None:
                loss_dt = WIB.localize(loss_dt)
            elapsed = (now - loss_dt).total_seconds() / 60
            if elapsed < POST_LOSS_COOLDOWN_MINUTES:
                logger.info("Post-LOSS cooldown: %.0f menit tersisa",
                            POST_LOSS_COOLDOWN_MINUTES - elapsed)
                return True
        except Exception as e:
            logger.warning("Parse last_loss_at: %s", e)

    return False


def mark_signal_sent(direction=None):
    state = _load_cooldown_state()
    state["last_signal_at"] = datetime.now(WIB).isoformat()
    if direction:
        state["last_direction"] = direction
    _save_cooldown_state(state)
    logger.info("Cooldown: sinyal %s terkirim", direction)


def mark_loss():
    state = _load_cooldown_state()
    state["last_loss_at"] = datetime.now(WIB).isoformat()
    _save_cooldown_state(state)
    logger.info("Post-LOSS cooldown 120 menit aktif")


# ============================================================
# SWING DETECTION
# ============================================================
def _get_swing_low(df, lookback=10):
    try:
        lows = df["low"].tail(lookback).values
        if len(lows) == 0:
            return 0.0
        return float(min(lows))
    except Exception:
        return 0.0


def _get_swing_high(df, lookback=10):
    try:
        highs = df["high"].tail(lookback).values
        if len(highs) == 0:
            return 0.0
        return float(max(highs))
    except Exception:
        return 0.0


# ============================================================
# RSI
# ============================================================
def _rsi_valid(direction, rsi):
    if direction == "BUY":
        return 40 <= rsi <= 68
    return 32 <= rsi <= 60


def _rsi_score(direction, rsi):
    if direction == "BUY":
        if 50 <= rsi <= 65:
            return 15
        elif 40 <= rsi < 50:
            return 10
        elif 65 < rsi <= 68:
            return 5
        return 0
    else:
        if 35 <= rsi <= 50:
            return 15
        elif 50 < rsi <= 60:
            return 10
        elif 32 <= rsi < 35:
            return 5
        return 0


# ============================================================
# SCORING
# ============================================================
def _calculate_score(direction, h1_trend, m15_trend, ema_aligned,
                     momentum_ok, rsi, rr):
    score = 0
    reasons = []

    # M15 (30)
    if (direction == "BUY" and m15_trend == "BULLISH") or \
       (direction == "SELL" and m15_trend == "BEARISH"):
        score += 30
        reasons.append(f"M15 {direction}")
    else:
        return 0, ["M15 tidak align"]

    # H1 (20/10)
    if (direction == "BUY" and h1_trend == "BULLISH") or \
       (direction == "SELL" and h1_trend == "BEARISH"):
        score += 20
        reasons.append(f"H1 {direction}")
    elif h1_trend == "NEUTRAL":
        score += 10
        reasons.append("H1 neutral")
    else:
        reasons.append(f"H1 konflik")

    # Momentum (20)
    if momentum_ok:
        score += 20
        reasons.append("Momentum")
    elif ema_aligned:
        score += 10
        reasons.append("EMA partial")

    # RSI (15)
    rsi_pts = _rsi_score(direction, rsi)
    if rsi_pts > 0:
        score += rsi_pts
        reasons.append(f"RSI {rsi:.1f}")

    # RR (15)
    if rr >= 2.0:
        score += 15
        reasons.append(f"RR 1:{rr:.1f}")
    elif rr >= MIN_RR:
        score += 10
        reasons.append(f"RR 1:{rr:.1f}")

    # PENALTI
    penalty = 0
    if direction == "BUY" and rsi > 70:
        penalty += 20
        reasons.append("RSI overbought -20")
    elif direction == "SELL" and rsi < 30:
        penalty += 20
        reasons.append("RSI oversold -20")

    if direction == "BUY" and 68 < rsi <= 70:
        penalty += 10
        reasons.append("RSI high -10")
    elif direction == "SELL" and 30 <= rsi < 32:
        penalty += 10
        reasons.append("RSI low -10")

    if h1_trend == "NEUTRAL":
        penalty += 5
        reasons.append("H1 neutral -5")

    score = max(score - penalty, 0)
    return min(score, 100), reasons


# ============================================================
# MAIN
# ============================================================
def calculate_signal(data):
    for tf in ["H1", "M15", "M5"]:
        if tf not in data or data[tf] is None or data[tf].empty:
            raise ValueError(f"Data {tf} kosong")

    h1_df = data["H1"]
    m15_df = data["M15"]
    m5_df = data["M5"]

    h1_last = h1_df.iloc[-1]
    m15_last = m15_df.iloc[-1]
    m5_last = m5_df.iloc[-1]

    price = _safe(m5_last.get("close"))
    if price <= 0:
        return _wait(0, "Harga invalid")

    ema20 = _safe(m5_last.get("ema20"))
    ema50 = _safe(m5_last.get("ema50"))
    ema200 = _safe(m5_last.get("ema200"))
    rsi = _safe(m5_last.get("rsi14"), 50)
    atr = _safe(m5_last.get("atr14"))

    if atr <= 0 or atr < MIN_ATR:
        return _wait(price, f"ATR rendah {atr:.2f}")

    if _check_cooldown():
        return _wait(price, "Cooldown aktif")

    h1_trend = _trend(h1_last.get("trend"))
    m15_trend = _trend(m15_last.get("trend"))

    jam_wib = datetime.now(WIB).hour
    if jam_wib in NOISE_HOURS:
        return _wait(price, f"Noise hour {jam_wib:02d}")

    # ========================================================
    # NEWS FILTER � STOP TRADING saat high-impact news
    # ========================================================
    try:
        from news_filter import is_news_time
        is_blocked, news_title = is_news_time(buffer_minutes=30)
        if is_blocked:
            logger.info("STOP TRADING: news high-impact 30 menit")
            return _wait(
                price,
                f"STOP TRADING - news high-impact dalam 30 menit"
            )
    except ImportError:
        pass
    except Exception as _e:
        logger.warning("News filter error: %s", _e)

    # Tentukan arah
    if h1_trend == "BULLISH" and m15_trend == "BULLISH":
        direction = "BUY"
    elif h1_trend == "BEARISH" and m15_trend == "BEARISH":
        direction = "SELL"
    elif h1_trend == "NEUTRAL" and m15_trend == "BULLISH":
        direction = "BUY"
    elif h1_trend == "NEUTRAL" and m15_trend == "BEARISH":
        direction = "SELL"
    else:
        return _wait(price, f"Trend konflik H1={h1_trend} M15={m15_trend}")

    if not _rsi_valid(direction, rsi):
        return _wait(price, f"RSI ekstrem {rsi:.1f}")

    # EMA/momentum
    if direction == "BUY":
        ema_aligned = ema20 > ema50 > ema200
        momentum_ok = ema_aligned and price > ema20
    else:
        ema_aligned = ema20 < ema50 < ema200
        momentum_ok = ema_aligned and price < ema20

    # SL
    if direction == "BUY":
        swing = _get_swing_low(m5_df, lookback=10)
        if swing <= 0:
            swing = _get_swing_low(m15_df, lookback=5)
        if swing <= 0:
            return _wait(price, "Swing low tidak ada")
        sl_price = swing - (atr * SL_ATR_BUFFER)
        risk = price - sl_price
    else:
        swing = _get_swing_high(m5_df, lookback=10)
        if swing <= 0:
            swing = _get_swing_high(m15_df, lookback=5)
        if swing <= 0:
            return _wait(price, "Swing high tidak ada")
        sl_price = swing + (atr * SL_ATR_BUFFER)
        risk = sl_price - price

    if risk <= 0:
        return _wait(price, "Risk <= 0")

    min_risk = atr * 0.50
    if risk < min_risk:
        risk = min_risk
        sl_price = price - risk if direction == "BUY" else price + risk

    if risk > (atr * 2.5):
        return _wait(price, f"SL lebar {risk:.2f}")

    # TP
    if direction == "BUY":
        tp1 = price + (risk * TP1_RR)
        tp2 = price + (risk * TP2_RR)
        tp3 = price + (risk * TP3_RR)
    else:
        tp1 = price - (risk * TP1_RR)
        tp2 = price - (risk * TP2_RR)
        tp3 = price - (risk * TP3_RR)

    rr_actual = abs(tp3 - price) / risk if risk > 0 else 0
    if rr_actual < MIN_RR:
        return _wait(price, f"RR rendah {rr_actual:.2f}")

    # Score
    confidence, reasons = _calculate_score(
        direction, h1_trend, m15_trend,
        ema_aligned, momentum_ok, rsi, rr_actual
    )

    if confidence < MIN_CONFIDENCE:
        return _wait(price, f"Skor {confidence} < {MIN_CONFIDENCE}")

    # Structure
    if direction == "BUY":
        structure = "TREND_BULLISH" if h1_trend == "BULLISH" else "M15_BULLISH"
    else:
        structure = "TREND_BEARISH" if h1_trend == "BEARISH" else "M15_BEARISH"

    reasons.append(f"ATR {atr:.2f}")
    reasons.append(f"Risk {risk:.2f}")

    session_name, session_emoji, session_status = get_market_session()

    return {
        "signal": direction,
        "confidence": int(min(confidence, 100)),
        "entry": round(price, 2),
        "sl": round(sl_price, 2),
        "tp1": round(tp1, 2),
        "tp2": round(tp2, 2),
        "tp3": round(tp3, 2),
        "risk": round(risk, 2),
        "rr": f"1:{rr_actual:.1f}",
        "structure": structure,
        "reasons": reasons,
        "session": session_name,
        "session_emoji": session_emoji,
        "session_status": session_status,
    }


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s"
    )

    try:
        from indicator_engine import get_indicator_data
        print("Mengambil data...")
        data = get_indicator_data()
        print("Menghitung sinyal...")
        result = calculate_signal(data)
        print()
        print("=" * 60)
        print("HASIL STRATEGI V5")
        print("=" * 60)
        if result["signal"] == "WAIT":
            print(f"Signal : WAIT")
            print(f"Reason : {result.get('reasons', [])}")
        else:
            for k, v in result.items():
                print(f"  {k}: {v}")
    except Exception as exc:
        import traceback
        traceback.print_exc()
