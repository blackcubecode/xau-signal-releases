"""
BLACK CUBE CODE - Signal Collector V3.2

Fungsi:
- Membaca sent_signal.json
- Menyimpan signal ke SQLite
- Tracking harga M15
- Mengirim notifikasi TP1 / TP2 / TP3 / SL / TIMEOUT
- Setiap event hanya dikirim 1 kali
"""

import asyncio
import json
import logging
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path

from signal_tracker import (
    save_signal,
    update_pending_signals,
    auto_expire_old_signals,
)

# ============================================================
# PATH
# ============================================================

from paths import BASE_DIR

SIGNAL_FILE = BASE_DIR / "sent_signal.json"
LAST_ID_FILE = BASE_DIR / ".collector_last_id"
NOTIFIED_FILE = BASE_DIR / "notified_closed.json"
DB_PATH = BASE_DIR / "signals_history.db"

CHECK_INTERVAL = 30


# ============================================================
# LOGGING
# ============================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[
        logging.FileHandler(
            BASE_DIR / "signal_collector.log"
        ),
        logging.StreamHandler(),
    ],
)

logging.getLogger("httpx").setLevel(logging.CRITICAL)
logging.getLogger("httpcore").setLevel(logging.CRITICAL)
logging.getLogger("telegram.request").setLevel(logging.CRITICAL)

logger = logging.getLogger(__name__)


# ============================================================
# NOTIFIED EVENTS
# ============================================================

def _load_notified():
    try:
        if NOTIFIED_FILE.exists():
            data = json.loads(
                NOTIFIED_FILE.read_text(
                    encoding="utf-8"
                )
            )

            if isinstance(data, list):
                return set(data)

    except Exception as e:
        logger.warning(
            "Gagal membaca notified_closed.json: %s",
            e,
        )

    return set()


def _save_notified(notified_set):
    try:
        # Simpan maksimal 500 event.
        items = list(notified_set)[-500:]

        NOTIFIED_FILE.write_text(
            json.dumps(
                items,
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )

    except Exception as e:
        logger.warning(
            "Gagal menyimpan notified event: %s",
            e,
        )


# ============================================================
# LAST SIGNAL ID
# ============================================================

def get_last_id():
    try:
        if LAST_ID_FILE.exists():
            return LAST_ID_FILE.read_text(
                encoding="utf-8"
            ).strip()
    except Exception:
        pass

    return ""


def set_last_id(signal_id):
    try:
        LAST_ID_FILE.write_text(
            str(signal_id),
            encoding="utf-8",
        )
    except Exception as e:
        logger.warning(
            "Gagal menyimpan last signal ID: %s",
            e,
        )


# ============================================================
# READ SIGNAL
# ============================================================

def read_signal():
    if not SIGNAL_FILE.exists():
        return None

    try:
        data = json.loads(
            SIGNAL_FILE.read_text(
                encoding="utf-8"
            )
        )

        if "signal_id" not in data:
            return None

        return data

    except Exception as e:
        logger.warning(
            "Baca sent_signal.json gagal: %s",
            e,
        )

        return None


# ============================================================
# TRACK MARKET
# ============================================================

def track_pending():
    try:

        from market_data import get_ohlc

        df = get_ohlc("15m")

        if df is None or df.empty:
            logger.warning(
                "Data M15 kosong."
            )
            return

        last = df.iloc[-1]

        current_high = float(last["high"])
        current_low = float(last["low"])

        logger.debug(
            "Tracker M15 | HIGH=%.3f LOW=%.3f",
            current_high,
            current_low,
        )

        update_pending_signals(
            current_high=current_high,
            current_low=current_low,
        )

    except Exception as e:
        logger.exception(
            "Tracking market gagal: %s",
            e,
        )


# ============================================================
# TELEGRAM
# ============================================================

def get_telegram_config():
    """
    Ambil token/chat ID dari environment.
    """

    import os

    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    chat_id = os.getenv("TELEGRAM_CHAT_ID", "").strip()

    if not token or not chat_id:

        # Coba baca .env sederhana.
        env_file = BASE_DIR / ".env"

        if env_file.exists():

            try:
                for line in env_file.read_text(
                    encoding="utf-8"
                ).splitlines():

                    line = line.strip()

                    if not line or line.startswith("#"):
                        continue

                    if "=" not in line:
                        continue

                    key, value = line.split(
                        "=",
                        1,
                    )

                    key = key.strip()
                    value = value.strip().strip('"').strip("'")

                    if key == "TELEGRAM_BOT_TOKEN" and not token:
                        token = value

                    elif key == "TELEGRAM_CHAT_ID" and not chat_id:
                        chat_id = value

            except Exception as e:
                logger.warning(
                    "Gagal membaca .env: %s",
                    e,
                )

    return token, chat_id


async def send_telegram(message):
    """
    Kirim pesan Telegram.
    """

    token, chat_id = get_telegram_config()

    if not token or not chat_id:

        logger.warning(
            "TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID belum tersedia."
        )

        return False

    try:

        from telegram import Bot

        bot = Bot(token=token)

        await bot.send_message(
            chat_id=chat_id,
            text=message,
        )

        return True

    except Exception as e:

        err_name = type(e).__name__

        # Handle flood control - tunggu lalu retry 1x
        if "RetryAfter" in err_name or "Flood" in str(e):
            import re as _re
            match = _re.search(r"(\d+)", str(e))
            wait = int(match.group(1)) + 2 if match else 35

            logger.warning(
                "Telegram flood control. Tunggu %s detik...",
                wait,
            )
            time.sleep(wait)

            # Retry sekali
            try:
                from telegram import Bot
                bot = Bot(token=token)
                await bot.send_message(
                    chat_id=chat_id,
                    text=message,
                )
                logger.info("Retry berhasil setelah flood control")
                return True
            except Exception as e2:
                logger.error("Retry gagal: %s", e2)
                return False

        logger.exception(
            "Gagal kirim Telegram: %s",
            e,
        )

        return False


# ============================================================
# FORMAT EVENT
# ============================================================

def _format_price(value):
    if value is None:
        return "-"

    try:
        return f"{float(value):.2f}"
    except Exception:
        return str(value)


def _get_event_price(sig, event):
    """
    Harga target berdasarkan event.
    """

    if event == "TP1_HIT":
        return sig["tp1"]

    if event == "TP2_HIT":
        return sig["tp2"]

    if event == "TP3_HIT":
        return sig["tp3"]

    if event == "SL_HIT":
        return sig["sl"]

    return None


def _get_event_emoji(event):
    """Emoji untuk setiap event - Unicode escape (RULE)."""
    emojis = {
        "TP1_HIT": "\U0001F947",
        "TP2_HIT": "\U0001F948",
        "TP3_HIT": "\U0001F949",
        "SL_HIT":  "\u26D4",
        "TIMEOUT": "\u23F0",
    }
    return emojis.get(event, "\U0001F4CC")


def _get_event_label(event):
    """Label text untuk event."""
    labels = {
        "TP1_HIT": "TP1 HIT",
        "TP2_HIT": "TP2 HIT",
        "TP3_HIT": "TP3 HIT",
        "SL_HIT": "SL HIT",
        "TIMEOUT": "TIMEOUT",
    }
    return labels.get(event, event)


def _format_price(value):
    """Format harga 2 desimal."""
    if value is None:
        return "-"
    try:
        return f"{float(value):.2f}"
    except Exception:
        return str(value)


def _get_event_price(sig, event):
    """Harga target berdasarkan event."""
    if event == "TP1_HIT":
        return sig["tp1"]
    if event == "TP2_HIT":
        return sig["tp2"]
    if event == "TP3_HIT":
        return sig["tp3"]
    if event == "SL_HIT":
        return sig["sl"]
    return None


def _calculate_points(sig, event):
    """Hitung points profit/loss."""
    try:
        entry = float(sig["entry"])
        price = _get_event_price(sig, event)
        if price is None:
            return None
        signal = str(sig["signal"]).upper()
        if signal == "BUY":
            return price - entry
        return entry - price
    except Exception:
        return None


def _format_closed_message(sig, event):
    """
    Format notifikasi TP/SL � V5 SIMPLE.
    RULE: pakai Unicode escape untuk emoji.
    """

    signal = str(sig["signal"]).upper()
    entry_raw = sig.get("entry")
    entry = _format_price(entry_raw)
    sl = _format_price(sig["sl"])
    tp1 = _format_price(sig["tp1"])
    tp2 = _format_price(sig["tp2"])
    tp3 = _format_price(sig["tp3"])

    # Event info
    if event == "TP1_HIT":
        emoji = "\U0001F947"
        label = "TP1 HIT"
        exit_price = tp1
    elif event == "TP2_HIT":
        emoji = "\U0001F948"
        label = "TP2 HIT"
        exit_price = tp2
    elif event == "TP3_HIT":
        emoji = "\U0001F3C6"
        label = "WIN FINAL"
        exit_price = tp3
    elif event == "SL_HIT":
        emoji = "\u26D4"
        label = "SL HIT"
        exit_price = sl
    elif event == "TIMEOUT":
        emoji = "\u23F0"
        label = "EXPIRED"
        exit_price = None
    else:
        emoji = "\U0001F4CC"
        label = event
        exit_price = None

    # P/L
    points = _calculate_points(sig, event)

    if points is not None:
        try:
            entry_float = float(entry_raw)
            pct = (points / entry_float) * 100 if entry_float > 0 else 0
        except Exception:
            pct = 0

        if points >= 0:
            result_emoji = "\U0001F4B0"
            result_label = "Profit"
            points_text = f"+{points:.2f} pts (+{pct:.2f}%)"
        else:
            result_emoji = "\U0001F4C9"
            result_label = "Loss"
            points_text = f"{points:.2f} pts ({pct:.2f}%)"
    else:
        result_emoji = "\U0001F4CA"
        result_label = "Status"
        points_text = "Belum hit TP/SL"

    # Waktu
    now_wib = datetime.now(timezone.utc).astimezone(
        __import__("zoneinfo").ZoneInfo("Asia/Jakarta")
    )
    time_str = now_wib.strftime("%d %b %Y, %H:%M WIB")

    # Durasi
    duration_text = ""
    try:
        sent_at = sig.get("sent_at")
        if sent_at:
            sent_str = str(sent_at).strip()
            if sent_str.endswith(" WIB"):
                sent_str = sent_str[:-4].strip()
            sent_dt = datetime.strptime(sent_str, "%Y-%m-%d %H:%M:%S")
            sent_dt = sent_dt.replace(
                tzinfo=__import__("zoneinfo").ZoneInfo("Asia/Jakarta")
            )
            delta = now_wib - sent_dt
            total_min = int(delta.total_seconds() / 60)
            if total_min < 1:
                duration_text = "< 1 menit"
            elif total_min < 60:
                duration_text = f"{total_min} menit"
            else:
                h = total_min // 60
                m = total_min % 60
                duration_text = f"{h} jam {m} menit" if m else f"{h} jam"
    except Exception:
        pass

    # Arah
    if signal == "BUY":
        arrow = "\U0001F7E2 BUY"
    else:
        arrow = "\U0001F534 SELL"

    # Build message
    lines = [
        f"{emoji} {label}",
        "",
        f"{arrow} XAUUSD \u2022 M15",
        "",
        f"\U0001F4CD Entry : {entry}",
    ]

    if exit_price:
        lines.append(f"\U0001F3C1 Exit  : {exit_price}")

    lines.append("")
    lines.append(f"{result_emoji} {result_label} : {points_text}")

    if duration_text:
        lines.append(f"\U0001F550 Durasi : {duration_text}")

    lines.append("")
    lines.append(f"_{time_str}_")

    return "\n".join(lines)


# ============================================================
# DATABASE EVENT CHECK (REWRITE v3.3)
# ============================================================

MAX_EVENTS_PER_CYCLE = 10       # max event per siklus
DELAY_BETWEEN_SEND = 2.0        # detik antar pesan


def get_new_events():
    """
    Ambil event dari database yang BELUM ada di notified.

    Return: list of dict {event_id, event, signal}
    Sudah difilter: hanya yang belum terkirim.
    """
    notified = _load_notified()

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row

    try:
        rows = conn.execute("""
            SELECT *
            FROM signals
            WHERE
                tp1_hit_at IS NOT NULL
                OR tp2_hit_at IS NOT NULL
                OR tp3_hit_at IS NOT NULL
                OR sl_hit_at IS NOT NULL
                OR status = 'EXPIRED'
                OR status IN ('WIN', 'LOSS')
                OR result IN ('TP1_HIT', 'TP2_HIT', 'TP3_HIT', 'SL_HIT')
            ORDER BY id ASC
        """).fetchall()

        events = []

        for row in rows:
            sig = dict(row)
            signal_id = sig.get("signal_id", "")
            if not signal_id:
                continue

            # Cek event yang mungkin ada
            checks = [
                ("TP1_HIT", sig.get("tp1_hit_at"), sig.get("result")),
                ("TP2_HIT", sig.get("tp2_hit_at"), sig.get("result")),
                ("TP3_HIT", sig.get("tp3_hit_at"), sig.get("result")),
                ("SL_HIT", sig.get("sl_hit_at"), sig.get("result")),
                ("TIMEOUT", None, sig.get("result")),
            ]

            for event, hit_at, result in checks:
                # Event valid kalau:
                # - hit_at ada (untuk TP/SL), ATAU
                # - result == event
                if event == "TIMEOUT":
                    if result != "TIMEOUT":
                        continue
                else:
                    if not (hit_at or result == event):
                        continue

                event_id = f"{signal_id}:{event}"

                # Skip kalau sudah pernah dikirim
                if event_id in notified:
                    continue

                events.append({
                    "event_id": event_id,
                    "event": event,
                    "signal": sig,
                })

        return events

    finally:
        conn.close()


def check_and_send_events():
    """
    Kirim event baru satu per satu, dengan rate limit.
    Skip event yang sudah pernah terkirim (ada di notified).
    Max MAX_EVENTS_PER_CYCLE per siklus.
    """
    events = get_new_events()

    if not events:
        return

    total = len(events)
    logger.info("Ditemukan %s event baru untuk dikirim", total)

    # Batasi jumlah per siklus
    if len(events) > MAX_EVENTS_PER_CYCLE:
        logger.warning(
            "Total %s event, proses %s dulu (sisa %s di siklus berikutnya)",
            total, MAX_EVENTS_PER_CYCLE, total - MAX_EVENTS_PER_CYCLE
        )
        events = events[:MAX_EVENTS_PER_CYCLE]

    notified = _load_notified()
    changed = False

    for item in events:
        event_id = item["event_id"]
        event = item["event"]
        sig = item["signal"]

        # Double check � sudah ada di notified
        if event_id in notified:
            continue

        message = _format_closed_message(sig, event)

        logger.info("Kirim event: %s", event_id)

        try:
            success = asyncio.run(send_telegram(message))
        except Exception as e:
            logger.exception("asyncio error: %s", e)
            success = False

        if success:
            notified.add(event_id)
            changed = True
            logger.info("Terkirim: %s", event_id)
            time.sleep(DELAY_BETWEEN_SEND)
        else:
            # Tandai juga sebagai notified supaya tidak loop
            notified.add(event_id)
            changed = True
            logger.warning("Gagal (ditandai terkirim): %s", event_id)
            time.sleep(DELAY_BETWEEN_SEND)

    if changed:
        _save_notified(notified)
        logger.info("notified_closed.json updated: %s events", len(notified))


# ============================================================
# NEW SIGNAL
# ============================================================

def check_new_signal():

    signal = read_signal()

    if not signal:
        return

    signal_id = signal.get("signal_id")

    if not signal_id:
        return

    last_id = get_last_id()

    if signal_id == last_id:
        return

    try:

        save_signal(signal)

        set_last_id(signal_id)

        logger.info(
            "Signal baru diproses: %s",
            signal_id,
        )

    except Exception as e:

        logger.exception(
            "Gagal memproses signal baru: %s",
            e,
        )


# ============================================================
# MAIN LOOP
# ============================================================

def main():

    logger.info(
        "? BLACK CUBE CODE - Signal Collector V3.2 started."
    )

    while True:

        try:

            # 1. Signal baru
            check_new_signal()

            # 2. Tracking harga
            track_pending()

            # 3. Timeout
            auto_expire_old_signals(
                hours=1
            )

            # 4. Kirim event Telegram
            check_and_send_events()

        except KeyboardInterrupt:

            logger.info(
                "Signal Collector dihentikan."
            )

            break

        except Exception as e:

            logger.exception(
                "Main loop error: %s",
                e,
            )

        time.sleep(
            CHECK_INTERVAL
        )


if __name__ == "__main__":
    main()
