#!/bin/bash
cd /home/admin/bots/xau_signal
source xau-venv/bin/activate

echo "=== HEALTH CHECK $(date) ==="

echo ""
echo "--- SERVICES ---"
for svc in xau-collector xau-signal xau-winrate xau-daily-news xau-news xau-weekly; do
    printf "%-20s %s\n" "$svc" "$(systemctl is-active ${svc}.service)"
done

echo ""
echo "--- SINYAL 24 JAM ---"
python3 -c "
import sqlite3
from datetime import datetime, timedelta
conn = sqlite3.connect('signals_history.db')
cutoff = (datetime.now() - timedelta(hours=24)).strftime('%Y-%m-%d %H:%M:%S')
rows = conn.execute('SELECT COUNT(*) FROM signals WHERE sent_at >= ?', (cutoff,)).fetchone()[0]
print(f'Sinyal 24 jam: {rows}')
conn.close()
"

echo ""
echo "--- DISK ---"
df -h /home | tail -1
