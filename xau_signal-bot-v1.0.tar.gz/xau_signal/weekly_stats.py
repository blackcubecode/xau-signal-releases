"""Statistik mingguan \u2014 kirim laporan tiap Senin 08:00 WIB."""
import os
import asyncio
import logging
import sqlite3
from datetime import datetime, timedelta
import pytz
from telegram import Bot
from dotenv import load_dotenv
from paths import ENV_FILE
load_dotenv(ENV_FILE)

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
WIB = pytz.timezone("Asia/Jakarta")
from paths import DB_PATH
DB_PATH = str(DB_PATH)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
logging.getLogger("httpx").setLevel(logging.CRITICAL)
logging.getLogger("httpcore").setLevel(logging.CRITICAL)
logging.getLogger("telegram.request").setLevel(logging.CRITICAL)
logger = logging.getLogger(__name__)

CHART = "\U0001F4CA"
CLOCK = "\U0001F550"
TROPHY = "\U0001F3C6"
CHECK = "\u2705"
CROSS = "\u274C"
HOURGLASS = "\u23F3"
TARGET = "\U0001F3AF"
BULB = "\U0001F4A1"
CAL = "\U0001F4C5"


def get_weekly_stats():
    """Ambil data 7 hari terakhir."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row

    # Window 7 hari terakhir (WIB)
    now_wib = datetime.now(WIB)
    week_start = (now_wib - timedelta(days=7)).isoformat()
    week_end = now_wib.isoformat()

    # Total per status
    rows = conn.execute("""
        SELECT status, result, COUNT(*) as c
        FROM signals
        WHERE sent_at >= ? OR sent_at >= ?
        GROUP BY status, result
    """, (week_start[:10], week_start)).fetchall()

    # Fallback: ambil 7 hari terakhir by ID (kalau sent_at format beda)
    total = conn.execute("SELECT COUNT(*) as c FROM signals").fetchone()["c"]
    wins = conn.execute("SELECT COUNT(*) as c FROM signals WHERE status='WIN'").fetchone()["c"]
    losses = conn.execute("SELECT COUNT(*) as c FROM signals WHERE status='LOSS'").fetchone()["c"]
    pending = conn.execute("SELECT COUNT(*) as c FROM signals WHERE status='PENDING'").fetchone()["c"]
    expired = conn.execute("SELECT COUNT(*) as c FROM signals WHERE status='EXPIRED'").fetchone()["c"]

    # Detail per hari (7 hari terakhir)
    daily = []
    for i in range(7):
        day = (now_wib - timedelta(days=i)).date()
        day_str = day.strftime("%Y-%m-%d")
        row = conn.execute("""
            SELECT
                COUNT(*) as total,
                SUM(CASE WHEN status='WIN' THEN 1 ELSE 0 END) as win,
                SUM(CASE WHEN status='LOSS' THEN 1 ELSE 0 END) as loss
            FROM signals
            WHERE sent_at LIKE ?
        """, (day_str + "%",)).fetchone()

        total_d = row["total"] or 0
        win_d = row["win"] or 0
        loss_d = row["loss"] or 0
        wr_d = (win_d / (win_d + loss_d) * 100) if (win_d + loss_d) > 0 else 0

        daily.append({
            "date": day,
            "day_name": day.strftime("%a"),
            "total": total_d,
            "win": win_d,
            "loss": loss_d,
            "winrate": round(wr_d, 1),
        })

    # TP breakdown
    tp1 = conn.execute("SELECT COUNT(*) as c FROM signals WHERE result='TP1_HIT'").fetchone()["c"]
    tp2 = conn.execute("SELECT COUNT(*) as c FROM signals WHERE result='TP2_HIT'").fetchone()["c"]
    tp3 = conn.execute("SELECT COUNT(*) as c FROM signals WHERE result='TP3_HIT'").fetchone()["c"]
    sl = conn.execute("SELECT COUNT(*) as c FROM signals WHERE result='SL_HIT'").fetchone()["c"]

    conn.close()

    closed = wins + losses
    winrate = (wins / closed * 100) if closed > 0 else 0

    return {
        "total": total,
        "wins": wins,
        "losses": losses,
        "pending": pending,
        "expired": expired,
        "winrate": round(winrate, 1),
        "tp1": tp1, "tp2": tp2, "tp3": tp3, "sl": sl,
        "daily": daily,
    }


def build_weekly_message():
    stats = get_weekly_stats()
    now_wib = datetime.now(WIB)
    week_ago = now_wib - timedelta(days=7)

    # Emoji performa
    wr = stats["winrate"]
    if wr >= 60:
        perf = "\U0001F525"
    elif wr >= 40:
        perf = "\U0001F44D"
    elif wr > 0:
        perf = "\u26A0\uFE0F"
    else:
        perf = HOURGLASS

    lines = [
        CHART + " LAPORAN MINGGUAN XAUUSD",
        CLOCK + " " + week_ago.strftime("%d %b") + " - " + now_wib.strftime("%d %b %Y"),
        "",
        perf + " RINGKASAN PERFORMA",
        "",
        TROPHY + " Total Sinyal : " + str(stats["total"]),
        CHECK + " Win          : " + str(stats["wins"]),
        CROSS + " Loss         : " + str(stats["losses"]),
        HOURGLASS + " Pending      : " + str(stats["pending"]),
        "\U0001F6AB Expired      : " + str(stats["expired"]),
        TARGET + " Winrate      : " + str(stats["winrate"]) + "%",
        "",
        "\U0001F4CC DETAIL TP / SL",
        "",
        "\U0001F947 TP1 Hit : " + str(stats["tp1"]) + "x",
        "\U0001F948 TP2 Hit : " + str(stats["tp2"]) + "x",
        "\U0001F949 TP3 Hit : " + str(stats["tp3"]) + "x",
        "\U0001F6D1 SL Hit  : " + str(stats["sl"]) + "x",
        "",
        CAL + " PER HARI (7 HARI TERAKHIR)",
        "",
    ]

    for d in stats["daily"]:
        if d["total"] > 0:
            lines.append(
                d["day_name"] + " " + d["date"].strftime("%d/%m") + " : "
                + str(d["total"]) + " sinyal (WR " + str(d["winrate"]) + "%)"
            )

    lines.append("")
    lines.append(BULB + " INSIGHT")

    # Insight otomatis
    best_day = max(stats["daily"], key=lambda x: x["winrate"]) if stats["daily"] else None
    worst_day = min([d for d in stats["daily"] if d["total"] > 0],
                    key=lambda x: x["winrate"], default=None)

    if best_day and best_day["total"] > 0:
        lines.append("Best : " + best_day["day_name"] + " (" + str(best_day["winrate"]) + "%)")
    if worst_day:
        lines.append("Worst: " + worst_day["day_name"] + " (" + str(worst_day["winrate"]) + "%)")

    lines.append("")
    lines.append("\u26A0\uFE0F Disclaimer: Sinyal bukan jaminan profit.")
    lines.append("Trading memiliki risiko.")

    return "\n".join(lines)


async def send_weekly(bot):
    try:
        msg = build_weekly_message()
        await bot.send_message(chat_id=CHAT_ID, text=msg, disable_web_page_preview=True)
        logger.info("Laporan mingguan terkirim.")
    except Exception as e:
        logger.exception("Gagal kirim laporan: %s", e)


async def main():
    bot = Bot(token=TOKEN)
    logger.info("Weekly stats started. Kirim tiap Senin 08:00 WIB.")

    while True:
        now = datetime.now(WIB)
        # Target: Senin berikutnya jam 08:00
        days_until_monday = (7 - now.weekday()) % 7
        if days_until_monday == 0 and now.hour >= 8:
            days_until_monday = 7

        target = (now + timedelta(days=days_until_monday)).replace(
            hour=8, minute=0, second=0, microsecond=0
        )

        wait_seconds = (target - now).total_seconds()
        logger.info("Next report: %s (%.1f jam lagi)",
                    target.strftime("%a %d %b %H:%M WIB"), wait_seconds / 3600)

        await asyncio.sleep(wait_seconds)
        await send_weekly(bot)


if __name__ == "__main__":
    asyncio.run(main())
