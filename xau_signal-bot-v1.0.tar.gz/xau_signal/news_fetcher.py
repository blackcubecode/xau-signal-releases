"""
Ambil berita XAU/USD dari RSS feed gratis.
Format plain text + emoji Unicode.
"""

import logging
from datetime import datetime
import requests
import xml.etree.ElementTree as ET

logger = logging.getLogger(__name__)

RSS_URL = "https://www.investing.com/rss/news_11.rss"
KEYWORDS = ["gold", "xau", "emas", "fed", "inflation", "dollar", "bullion", "rate"]


def fetch_gold_news(limit: int = 3) -> list:
    news = []

    try:
        r = requests.get(
            RSS_URL,
            timeout=10,
            headers={"User-Agent": "Mozilla/5.0"},
        )
        r.raise_for_status()

        root = ET.fromstring(r.content)
        items = root.findall(".//item")

        for item in items:
            title = item.findtext("title", "").strip()
            if any(kw.lower() in title.lower() for kw in KEYWORDS):
                news.append({
                    "title": title,
                    "link": item.findtext("link", "").strip(),
                })
                if len(news) >= limit:
                    break

        if not news:
            for item in items[:limit]:
                news.append({
                    "title": item.findtext("title", "").strip(),
                    "link": item.findtext("link", "").strip(),
                })

    except Exception as e:
        logger.warning("Gagal ambil news: %s", e)
        news = [{
            "title": "News feed tidak tersedia. Cek forexfactory.com",
            "link": "https://www.forexfactory.com/calendar",
        }]

    return news


def format_news_message(news: list) -> str:
    sep = "\u2501" * 18

    if not news:
        return (
            "\U0001F4F0 NEWS XAU/USD\n"
            f"{sep}\n\n"
            "\U0001F7E2 Tidak ada berita terbaru\n\n"
            "_Black Cube Code_"
        )

    now_wib = datetime.now().strftime("%d %b %Y, %H:%M WIB")

    lines = [
        "\U0001F4F0 NEWS XAU/USD",
        sep,
        "",
    ]

    for i, item in enumerate(news, 1):
        title = item["title"][:120]
        lines.append(f"{i}\uFE0F\u20E3 {title}")
        lines.append("")

    lines.append(f"_{now_wib}_")
    lines.append("_Black Cube Code_")

    return "\n".join(lines).strip()
