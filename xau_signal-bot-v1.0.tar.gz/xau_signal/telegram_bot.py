import os
import json
import asyncio
import logging

from license_check import verify_license
verify_license()
from pathlib import Path
from datetime import datetime, timedelta

import pandas as pd
import pytz

from dotenv import load_dotenv

from telegram import Bot
from telegram.error import TelegramError

from indicator_engine import get_indicator_data
from strategy import calculate_signal
from chart_generator import generate_signal_chart
from news_filter import is_news_time


# ============================================================
# BLACK CUBE CODE
# XAUUSD TELEGRAM SIGNAL BOT
# M15 CLOSED CANDLE EDITION
# ============================================================


from paths import WEEKEND_FLAG_FILE, MONDAY_FLAG_FILE


def is_monday_notified():
    try:
        data = json.loads(MONDAY_FLAG_FILE.read_text())
        return data.get("monday_notified", False)
    except Exception:
        return False


def set_monday_notified(value):
    try:
        MONDAY_FLAG_FILE.write_text(json.dumps({"monday_notified": value}))
    except Exception:
        pass


def is_weekend_notified():
    try:
        data = json.loads(WEEKEND_FLAG_FILE.read_text())
        return data.get("weekend_notified", False)
    except Exception:
        return False


def set_weekend_notified(value):
    try:
        WEEKEND_FLAG_FILE.write_text(json.dumps({"weekend_notified": value}))
    except Exception:
        pass


# ============================================================
# BASE CONFIG
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

ENV_FILE = BASE_DIR / ".env"

load_dotenv(
    dotenv_path=ENV_FILE,
    override=True
)


BOT_TOKEN = os.getenv(
    "TELEGRAM_BOT_TOKEN"
)

CHAT_ID = os.getenv(
    "TELEGRAM_CHAT_ID"
)



# ============================================================
# MODE
# ============================================================

# True  = kirim TEST SIGNAL satu kali lalu berhenti
# False = NORMAL MODE

TEST_MODE = False


# ============================================================
# BOT SETTINGS
# ============================================================

# Bot tetap mengecek setiap 60 detik.
#
# TETAPI signal engine tidak dihitung setiap 60 detik.
#
# Strategy hanya dihitung:
# 1x untuk setiap candle M15 yang sudah CLOSED.

CHECK_INTERVAL = 60


# ============================================================
# QRIS DONATION SETTINGS
# ============================================================

QRIS_SEND_HOUR = 8
QRIS_STATE_FILE = BASE_DIR / "qris_last_sent.json"

# Emoji tambahan (Unicode escape)
EMOJI_GIFT = "\U0001F381"
EMOJI_PRAY = "\U0001F64F"


# ============================================================
# SIGNAL SETTINGS
# ============================================================

SIGNAL_TIMEFRAME_MINUTES = 15


# Candle M15 terakhir yang sudah diproses.
#
# Contoh:
#
# 2026-09-21 09:00
#
# Selama candle tersebut masih menjadi candle terakhir
# yang sudah closed, bot tidak akan menghitung ulang.
#
# Setelah muncul:
#
# 2026-09-21 09:15
#
# strategy akan dihitung kembali.

LAST_PROCESSED_M15 = None


# ============================================================
# LOG THROTTLE (untuk hemat log spam)
# ============================================================

# Jam terakhir log "MARKET OFF" ditulis.
# Log hanya ditulis kalau jam berubah (1x per jam).
LAST_MARKET_OFF_LOG_HOUR = None


# ============================================================
# FILE
# ============================================================

SENT_FILE = BASE_DIR / "sent_signal.json"


# ============================================================
# TIMEZONE
# ============================================================

WIB = pytz.timezone(
    "Asia/Jakarta"
)


# ============================================================
# EMOJI
# Semua emoji menggunakan Unicode escape.
# ============================================================

BLACK = "\u2B1B"

VIP_ICON = "\U0001F48E"

BUY_ICON = "\U0001F7E2"

SELL_ICON = "\U0001F534"

ENTRY_ICON = "\U0001F4CD"

SL_ICON = "\U0001F6D1"

TP_ICON = "\U0001F3AF"

CONFIDENCE_ICON = "\U0001F4CA"

SETUP_ICON = "\u26A1"

COFFEE_ICON = "\u2615\uFE0F"


# ============================================================
# QRIS DONATION CAPTIONS
# ============================================================
# Didefinisikan SETELAH semua emoji icon di atas
# supaya tidak ada NameError.

QRIS_CAPTIONS = [
    f"{COFFEE_ICON} Support Black Cube Code",
    f"{COFFEE_ICON} Traktir kopi developer",
    f"{COFFEE_ICON} Donasi via QRIS",
    f"{COFFEE_ICON} Bantu server tetap online",
    f"{VIP_ICON} Apresiasi untuk Black Cube Code",
    f"{EMOJI_GIFT} Donasi sukarela via QRIS",
    f"{SETUP_ICON} Support pengembangan bot",
    f"{EMOJI_PRAY} Terima kasih atas dukungannya",
]

LINK_ICON = "\U0001F517"

TIME_ICON = "\U0001F552"


# ============================================================
# LOGGING
# ============================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)


logger = logging.getLogger(
    "XAU_SIGNAL_BOT"
)


# ============================================================
# HIDE TELEGRAM HTTP TOKEN
# ============================================================
#
# python-telegram-bot menggunakan httpx.
#
# Jika logging HTTP berada di INFO,
# URL seperti:
#
# https://api.telegram.org/bot<TOKEN>/getMe
#
# dapat muncul di terminal.
#
# Kita matikan logging HTTP tersebut.

logging.getLogger(
    "httpx"
).setLevel(
    logging.WARNING
)

logging.getLogger(
    "httpcore"
).setLevel(
    logging.WARNING
)


# ============================================================
# ENV VALIDATION
# ============================================================

if not BOT_TOKEN:

    raise RuntimeError(
        "TELEGRAM_BOT_TOKEN tidak ditemukan di .env"
    )


if not CHAT_ID:

    raise RuntimeError(
        "TELEGRAM_CHAT_ID tidak ditemukan di .env"
    )


# ============================================================
# TELEGRAM BOT
# ============================================================

bot = Bot(
    token=BOT_TOKEN
)


# ============================================================
# TIME
# ============================================================

def now_wib():

    return datetime.now(
        WIB
    )


def format_wib():

    return now_wib().strftime(
        "%d %b %Y - %H:%M WIB"
    )


# ============================================================
# MARKET DAY FILTER
# ============================================================

def is_weekend_wib():
    """
    Sabtu dan Minggu = OFF.

    Monday    = 0
    Tuesday   = 1
    Wednesday = 2
    Thursday  = 3
    Friday    = 4
    Saturday  = 5
    Sunday    = 6
    """

    now = now_wib()

    return now.weekday() in (
        5,
        6
    )


def weekend_status():

    now = now_wib()

    if now.weekday() == 5:

        return "SATURDAY"

    if now.weekday() == 6:

        return "SUNDAY"

    return None


# ============================================================
# TRADING SESSION FILTER
# ============================================================

def get_trading_session():
    """
    Cek session trading berdasarkan jam WIB.

    Return:
        (is_active, session_name)

    Session:
        ASIA        : 08:00 - 14:00 WIB (volatil rendah)
        LONDON      : 14:00 - 19:00 WIB (volatil sedang)
        LONDON_NY   : 19:00 - 23:00 WIB (volatil TINGGI) ?
        NY          : 23:00 - 04:00 WIB (volatil sedang)
        OFF         : 04:00 - 08:00 WIB (sepi)
    """

    now = now_wib()
    hour = now.hour

    # Asia (aktif mulai 08:00 WIB)
    if 8 <= hour < 14:
        return True, "ASIA"

    # London (sedang)
    if 14 <= hour < 19:
        return True, "LONDON"

    # London + NY overlap (TINGGI) ?
    if 19 <= hour < 23:
        return True, "LONDON_NY_OVERLAP"

    # NY (sedang)
    if hour >= 23 or hour < 4:
        return True, "NEW_YORK"

    # Off-hours (sepi)
    return False, "OFF_HOURS"


# ============================================================
# NORMALIZE TIMESTAMP
# ============================================================

def normalize_timestamp_to_wib(
    timestamp
):
    """
    Mengubah timestamp dataframe
    menjadi timezone WIB.

    Jika timestamp tidak memiliki timezone,
    diasumsikan data market sudah dalam WIB.
    """

    ts = pd.Timestamp(
        timestamp
    )

    # --------------------------------------------------------
    # Naive timestamp
    # --------------------------------------------------------

    if ts.tzinfo is None:

        ts = ts.tz_localize(
            WIB
        )

    # --------------------------------------------------------
    # Aware timestamp
    # --------------------------------------------------------

    else:

        ts = ts.tz_convert(
            WIB
        )

    return ts


# ============================================================
# GET CLOSED MARKET DATA
# ============================================================

def get_closed_market_data(
    data
):
    """
    Mengambil hanya candle yang sudah CLOSED.

    M5  = candle M5 closed
    M15 = candle M15 closed
    H1  = candle H1 closed

    Candle yang masih berjalan dibuang.
    """

    timeframe_minutes = {

        "M5": 5,

        "M15": 15,

        "H1": 60
    }


    now = pd.Timestamp(
        now_wib()
    )


    closed_data = {}


    for timeframe, dataframe in data.items():

        # ----------------------------------------------------
        # Validate dataframe
        # ----------------------------------------------------

        if dataframe is None:

            continue


        if len(dataframe) < 3:

            continue


        df = dataframe.copy()


        # ----------------------------------------------------
        # Sort
        # ----------------------------------------------------

        df = df.sort_index()


        minutes = timeframe_minutes.get(
            timeframe
        )


        if minutes is None:

            continue


        # ----------------------------------------------------
        # Find closed candles
        # ----------------------------------------------------

        valid_rows = []


        for timestamp in df.index:

            try:

                candle_open = (
                    normalize_timestamp_to_wib(
                        timestamp
                    )
                )


                candle_close = (
                    candle_open
                    + timedelta(
                        minutes=minutes
                    )
                )


                # ------------------------------------------------
                # Candle sudah benar-benar selesai
                # ------------------------------------------------

                if candle_close <= now:

                    valid_rows.append(
                        timestamp
                    )


            except Exception:

                continue


        # ----------------------------------------------------
        # Tidak ada candle closed
        # ----------------------------------------------------

        if not valid_rows:

            continue


        closed_df = df.loc[
            valid_rows
        ].copy()


        if len(closed_df) < 3:

            continue


        closed_data[
            timeframe
        ] = closed_df


    return closed_data


# ============================================================
# GET LATEST CLOSED M15
# ============================================================

def get_latest_closed_m15_timestamp(
    closed_data
):

    m15 = closed_data.get(
        "M15"
    )


    if m15 is None:

        return None


    if len(m15) == 0:

        return None


    # BiQuote menyimpan waktu candle pada kolom "datetime",
    # bukan pada dataframe index.
    if "datetime" in m15.columns:

        timestamp = m15["datetime"].iloc[-1]

    else:

        timestamp = m15.index[-1]


    timestamp = (
        normalize_timestamp_to_wib(
            timestamp
        )
    )


    return timestamp


# ============================================================
# GET M15 KEY
# ============================================================

def get_latest_closed_m15_key(
    closed_data
):

    timestamp = (
        get_latest_closed_m15_timestamp(
            closed_data
        )
    )


    if timestamp is None:

        return None


    return timestamp.strftime(
        "%Y-%m-%d %H:%M"
    )


# ============================================================
# SENT SIGNAL
# ============================================================

def load_sent_signal():
    """
    Membaca signal terakhir
    yang sudah dikirim.
    """

    if not SENT_FILE.exists():

        return None


    try:

        with open(
            SENT_FILE,
            "r",
            encoding="utf-8"
        ) as f:

            return json.load(
                f
            )


    except Exception as e:

        logger.warning(
            "Gagal membaca sent_signal.json: %s",
            e
        )

        return None


# ============================================================
# SAVE SENT SIGNAL
# ============================================================

def save_sent_signal(
    signal_data
):
    """
    Menyimpan signal terakhir.
    """

    try:

        with open(
            SENT_FILE,
            "w",
            encoding="utf-8"
        ) as f:

            json.dump(
                signal_data,
                f,
                indent=2,
                ensure_ascii=False
            )

        # ============================================
        # UPDATE COOLDOWN STATE
        # ============================================
        try:
            from strategy import mark_signal_sent
            direction = signal_data.get("signal")
            if direction in ("BUY", "SELL"):
                mark_signal_sent(direction)
                logger.info(
                    "Cooldown state: %s @ %s",
                    direction,
                    datetime.now().strftime("%H:%M WIB")
                )
        except Exception as e:
            logger.warning(
                "mark_signal_sent gagal: %s",
                e
            )


    except Exception as e:

        logger.error(
            "Gagal menyimpan signal: %s",
            e
        )


# ============================================================
# SIGNAL ID
# ============================================================

def make_signal_id(
    result
):
    """
    Membuat ID unik berdasarkan:
    signal + entry + SL + TP1.
    """

    return (
        f"{result['signal']}_"
        f"{result['entry']}_"
        f"{result['sl']}_"
        f"{result['tp1']}"
    )


# ============================================================
# TEST SIGNAL
# ============================================================

def format_test_signal():
    """
    Format TEST SIGNAL VIP.
    """

    lines = []


    lines.append(
        f"{BLACK} BLACK CUBE CODE"
    )


    lines.append(
        f"{VIP_ICON} VIP TRADING SIGNAL"
    )


    lines.append("")


    lines.append(
        "XAUUSD \u2022 M15"
    )


    lines.append("")


    lines.append(
        f"{BUY_ICON} BUY SIGNAL"
    )


    lines.append("")


    lines.append(
        f"{TIME_ICON} TIME"
    )


    lines.append(
        format_wib()
    )


    lines.append("")


    lines.append(
        f"{ENTRY_ICON} ENTRY"
    )


    lines.append(
        "4380.92"
    )


    lines.append("")


    lines.append(
        f"{SL_ICON} STOP LOSS"
    )


    lines.append(
        "4368.70"
    )


    lines.append("")


    lines.append(
        f"{TP_ICON} TAKE PROFIT"
    )


    lines.append("")


    lines.append(
        "TP1  \u2022 4393.14"
    )


    lines.append(
        "TP2  \u2022 4405.36"
    )


    lines.append(
        "TP3  \u2022 4417.58"
    )


    lines.append("")


    lines.append(
        f"{CONFIDENCE_ICON} CONFIDENCE"
    )


    lines.append(
        "82%"
    )


    lines.append("")


    lines.append(
        f"{SETUP_ICON} MARKET SETUP"
    )


    lines.append(
        "Trend Alignment"
    )


    lines.append(
        "Momentum Confirmation"
    )


    lines.append("")


    lines.append("")


    lines.append(
        "TEST MODE - Telegram connection OK"
    )


    return "\n".join(
        lines
    )


# ============================================================
# NORMAL SIGNAL FORMAT
# ============================================================

def format_signal(result):
    """
    Format signal entry � V5 SIMPLE.
    RULE: pakai Unicode escape untuk emoji.
    """

    signal = str(result.get("signal", "")).upper()

    if signal not in ("BUY", "SELL"):
        return None

    entry = float(result.get("entry", 0))
    sl = float(result.get("sl", 0))
    tp1 = float(result.get("tp1", 0))
    tp2 = float(result.get("tp2", 0))
    tp3 = float(result.get("tp3", 0))

    confidence = result.get("confidence", 0)
    structure = result.get("structure", "-")

    # Jarak & R:R
    sl_dist = abs(entry - sl)
    tp1_dist = abs(tp1 - entry)
    tp2_dist = abs(tp2 - entry)
    tp3_dist = abs(tp3 - entry)

    risk = sl_dist if sl_dist > 0 else 0
    rr1 = (tp1_dist / risk) if risk > 0 else 0
    rr2 = (tp2_dist / risk) if risk > 0 else 0
    rr3 = (tp3_dist / risk) if risk > 0 else 0

    # Tanda +/-
    def _sgn(val, ref):
        return "+" if val >= ref else "-"

    sl_sign = _sgn(sl, entry)
    tp1_sign = _sgn(tp1, entry)
    tp2_sign = _sgn(tp2, entry)
    tp3_sign = _sgn(tp3, entry)

    # Emoji arah
    if signal == "BUY":
        arrow = "\U0001F7E2 BUY"
    else:
        arrow = "\U0001F534 SELL"

    # Waktu
    try:
        time_str = format_wib()
    except Exception:
        time_str = datetime.now().strftime("%d %b %Y, %H:%M WIB")

    # Session info
    session_name = result.get("session", "-")
    session_emoji = result.get("session_emoji", "\U0001F30D")
    session_status = result.get("session_status", "-")

    lines = [
        "\u2B1B BLACK CUBE CODE",
        "\U0001F48E VIP TRADING SIGNAL",
        "",
        f"{arrow} XAUUSD \u2022 M15",
        f"\U0001F550 {time_str}",
        f"\U0001F4CD Sesi : {session_emoji} {session_name} ({session_status})",
        "",
        f"\U0001F4CA Conf : {confidence}% | {structure}",
        "",
        f"\U0001F4CD Entry : {entry:.2f}",
        f"\U0001F6D1 SL    : {sl:.2f} ({sl_sign}{sl_dist:.2f})",
        "",
        f"\U0001F3AF TP1   : {tp1:.2f} ({tp1_sign}{tp1_dist:.2f})",
        f"\U0001F3AF TP2   : {tp2:.2f} ({tp2_sign}{tp2_dist:.2f})",
        f"\U0001F3AF TP3   : {tp3:.2f} ({tp3_sign}{tp3_dist:.2f})",
        "",
        f"\u2696\uFE0F R:R   : 1:{rr1:.1f} | 1:{rr2:.1f} | 1:{rr3:.1f}",
        "",
        "\u26A0\uFE0F Risk management 1-2% per trade",
    ]

    return "\n".join(lines)


async def send_message(
    message,
    bot=None,
):
    """Kirim pesan Telegram ke CHAT_ID."""
    if bot is None:
        if not BOT_TOKEN:
            logger.error("BOT_TOKEN tidak ada.")
            return False
        bot = Bot(token=BOT_TOKEN)

    try:
        await bot.send_message(
            chat_id=CHAT_ID,
            text=message,
        )
        return True
    except Exception as e:
        logger.error("Gagal kirim: %s", e)
        return False



async def send_chart(
    result,
    m15_data
):
    """
    Membuat dan mengirim chart M15.
    """

    try:

        logger.info(
            "Membuat chart XAUUSD M15..."
        )


        chart_image = (
            generate_signal_chart(

                dataframe=m15_data,

                signal=result["signal"],

                entry=result["entry"],

                sl=result["sl"],

                tp1=result["tp1"],

                tp2=result["tp2"],

                tp3=result["tp3"],

                confidence=result.get(
                    "confidence",
                    0
                ),

                structure=result.get(
                    "structure",
                    "UNKNOWN"
                )
            )
        )


        await bot.send_photo(

            chat_id=CHAT_ID,

            photo=chart_image
        )


        logger.info(
            "Chart signal berhasil dikirim."
        )


        return True


    except TelegramError as e:

        logger.error(
            "Telegram chart error: %s",
            e
        )


        return False


    except Exception as e:

        logger.exception(
            "Gagal membuat/mengirim chart: %s",
            e
        )


        return False
# ============================================================
# QRIS STATE & LOGIC
# ============================================================

def should_send_qris():
    """
    Cek apakah QRIS donasi perlu dikirim hari ini.
    Return True kalau:
    - Belum kirim hari ini, DAN
    - Sudah jam QRIS_SEND_HOUR WIB atau lebih
    """

    now = now_wib()
    today = now.strftime("%Y-%m-%d")

    if QRIS_STATE_FILE.exists():

        try:

            with open(
                QRIS_STATE_FILE,
                "r",
                encoding="utf-8"
            ) as f:

                state = json.load(f)

            if state.get("last_sent_date") == today:

                return False

        except Exception:

            pass

    if now.hour < QRIS_SEND_HOUR:

        return False

    return True


def mark_qris_sent():
    """Catat QRIS sudah dikirim hari ini."""

    today = now_wib().strftime("%Y-%m-%d")

    try:

        with open(
            QRIS_STATE_FILE,
            "w",
            encoding="utf-8"
        ) as f:

            json.dump(
                {"last_sent_date": today},
                f,
                ensure_ascii=False
            )

    except Exception as e:

        logger.exception(
            "Gagal simpan QRIS state: %s",
            e
        )


def get_qris_caption():
    """Ambil caption donasi random."""

    import random

    return random.choice(QRIS_CAPTIONS)


# ============================================================
# SEND QRIS
# ============================================================

async def send_qris():
    """
    Mengirim gambar QRIS ke Telegram.
    """

    from paths import QRIS_PATH
    qris_path = str(QRIS_PATH)

    try:

        with open(qris_path, "rb") as qris_file:

            await bot.send_photo(
                chat_id=CHAT_ID,
                photo=qris_file,
                caption=get_qris_caption()
            )

        logger.info(
            "QRIS berhasil dikirim ke Telegram."
        )

        mark_qris_sent()

        return True

    except TelegramError as e:

        logger.error(
            "Telegram error mengirim QRIS: %s",
            e
        )

        return False

    except Exception as e:

        logger.error(
            "Error mengirim QRIS: %s",
            e
        )

        return False


# ============================================================
# TEST MODE
# ============================================================

async def run_test():

    logger.info(
        "=========================================="
    )


    logger.info(
        "TEST MODE AKTIF"
    )


    logger.info(
        "Mengirim TEST BUY ke Telegram..."
    )


    message = format_test_signal()


    success = await send_message(
        message
    )


    if success:

        logger.info(
            "TEST SIGNAL BERHASIL DIKIRIM."
        )


        logger.info(
            "Silakan cek Telegram."
        )


    else:

        logger.error(
            "TEST SIGNAL GAGAL DIKIRIM."
        )


# ============================================================
# CHECK SIGNAL
# ============================================================

async def check_signal():

    global LAST_PROCESSED_M15

    global LAST_MARKET_OFF_LOG_HOUR


    try:

        # ====================================================
        # RESET WEEKEND FLAG
        # ====================================================

        if not is_weekend_wib() and is_weekend_notified():

            set_weekend_notified(False)

            logger.info("Flag weekend di-reset.")

        # ====================================================
        # PESAN SENIN PAGI (sekali saja)
        # ====================================================

        is_monday = datetime.now(WIB).weekday() == 0

        if is_monday and not is_monday_notified():

            try:

                _now = datetime.now(WIB)
                monday_msg = (
                    "\u2600\uFE0F SELAMAT PAGI TRADER\n"
                    "\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\n\n"
                    "\U0001F4C5 " + _now.strftime("%A, %d %b %Y") + "\n"
                    "\U0001F550 Market XAUUSD dibuka\n\n"
                    "\U0001F4E1 Bot siap memantau market 24/7\n"
                    "\U0001F3AF Sinyal trading aktif kembali\n\n"
                    "\U0001F4AA Semoga profit minggu ini!\n\n"
                    "_Black Cube Code_"
                )

                await bot.send_message(
                    chat_id=CHAT_ID,
                    text=monday_msg
                )

                set_monday_notified(True)

                logger.info("Pesan Senin terkirim.")

            except Exception as e:

                logger.error(
                    "Gagal kirim pesan Senin: %s",
                    e
                )

        # Reset flag Senin kalau bukan hari Senin
        if not is_monday and is_monday_notified():

            set_monday_notified(False)

            logger.info("Flag Senin di-reset.")


        # ====================================================
        # TRADING SESSION FILTER
        # Hanya kirim sinyal saat London/NY session
        # ====================================================

        session_active, session_name = get_trading_session()

        if not session_active:

            logger.info(
                "Session %s - volatilitas rendah. SKIP signal.",
                session_name
            )

            return

        # ====================================================
        # WEEKEND FILTER
        # ====================================================

        if is_weekend_wib():

            # ------------------------------------------------
            # Kirim pesan weekend sekali (Sabtu pagi)
            # ------------------------------------------------

            if not is_weekend_notified():

                try:

                    weekend_msg = (
                        "\U0001F319 MARKET TUTUP\n"
                        "\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\n\n"
                        "\U0001F4C5 Sabtu - Minggu\n"
                        "\U0001F512 XAUUSD tutup\n\n"
                        "\U0001F4E1 Bot akan aktif kembali\n"
                        "\U0001F550 Senin, 06:00 WIB (Sesi Asia)\n\n"
                        "\U0001F64F Selamat beristirahat\n\n"
                        "\U0001F4A1 Tips: Review performa trading minggu ini\n\n"
                        "_Black Cube Code_"
                    )

                    await bot.send_message(
                        chat_id=CHAT_ID,
                        text=weekend_msg
                    )

                    set_weekend_notified(True)

                    logger.info("Pesan weekend terkirim.")

                except Exception as e:

                    logger.error(
                        "Gagal kirim pesan weekend: %s",
                        e
                    )

            # ------------------------------------------------
            # Log throttle: hanya 1x per jam
            # ------------------------------------------------

            current_hour = now_wib().strftime("%Y-%m-%d %H")


            if LAST_MARKET_OFF_LOG_HOUR != current_hour:

                LAST_MARKET_OFF_LOG_HOUR = current_hour

                day_name = weekend_status()


                logger.info(
                    "MARKET OFF - %s WIB.",
                    day_name
                )


                logger.info(
                    "Signal engine tidak dijalankan."
                )

            # ------------------------------------------------
            # STOP \u2014 JANGAN LANJUT KE MARKET DATA
            # ------------------------------------------------

            return

        # ====================================================
        # NEWS FILTER
        # Skip sinyal kalau dekat news high-impact USD
        # ====================================================

        is_news, news_title = is_news_time(buffer_minutes=30)

        if is_news:

            logger.info(
                "SKIP - dekat news high-impact: %s",
                news_title
            )

            return


        # ====================================================
        # GET MARKET DATA
        # ====================================================

        logger.info(
            "Mengambil market data..."
        )


        data = get_indicator_data()


        # ====================================================
        # CLOSED CANDLE FILTER
        # ====================================================

        closed_data = (
            get_closed_market_data(
                data
            )
        )


        if not closed_data:

            logger.info(
                "Belum ada closed candle valid."
            )


            return


        # ====================================================
        # M15
        # ====================================================

        m15_closed = closed_data.get(
            "M15"
        )


        if m15_closed is None:

            logger.info(
                "M15 closed candle belum tersedia."
            )


            return


        if len(m15_closed) < 3:

            logger.info(
                "Data M15 closed terlalu sedikit."
            )


            return


        # ====================================================
        # LATEST CLOSED M15
        # ====================================================

        latest_m15_timestamp = (
            get_latest_closed_m15_timestamp(
                closed_data
            )
        )


        if latest_m15_timestamp is None:

            logger.info(
                "Tidak dapat menentukan "
                "closed M15 candle."
            )


            return


        current_m15_key = (
            latest_m15_timestamp.strftime(
                "%Y-%m-%d %H:%M"
            )
        )


        # ====================================================
        # ANTI NOISE
        # ====================================================

        if (
            LAST_PROCESSED_M15
            == current_m15_key
        ):

            logger.info(
                "M15 %s sudah diproses. "
                "SKIP.",
                current_m15_key
            )


            return


        # ====================================================
        # NEW M15
        # ====================================================

        logger.info(
            "=========================================="
        )


        logger.info(
            "NEW CLOSED M15 CANDLE"
        )


        logger.info(
            "Candle : %s WIB",
            current_m15_key
        )


        logger.info(
            "Strategy hanya dihitung 1x."
        )


        logger.info(
            "=========================================="
        )


        # ====================================================
        # MARK PROCESSED
        # ====================================================

        LAST_PROCESSED_M15 = (
            current_m15_key
        )


        # ====================================================
        # CALCULATE SIGNAL
        # ====================================================

        result = calculate_signal(
            closed_data
        )


        # ====================================================
        # READ RESULT
        # ====================================================

        signal = result.get(
            "signal",
            "WAIT"
        )


        confidence = result.get(
            "confidence",
            0
        )


        structure = result.get(
            "structure",
            "UNKNOWN"
        )


        # ====================================================
        # LOG
        # ====================================================

        logger.info(
            "Signal=%s | Confidence=%s | Structure=%s | M15=%s",
            signal,
            confidence,
            structure,
            current_m15_key
        )


        # ====================================================
        # WAIT
        # ====================================================

        if signal == "WAIT":

            logger.info(
                "WAIT - tidak mengirim Telegram."
            )


            return


        # ====================================================
        # VALIDATE SIGNAL
        # ====================================================

        if signal not in (
            "BUY",
            "SELL"
        ):

            logger.warning(
                "Signal tidak dikenal: %s",
                signal
            )


            return


        # ====================================================
        # SIGNAL ID
        # ====================================================

        signal_id = make_signal_id(
            result
        )


        # ====================================================
        # PREVIOUS SIGNAL
        # ====================================================

        previous = load_sent_signal()


        if previous:

            if (
                previous.get(
                    "signal_id"
                )
                == signal_id
            ):

                logger.info(
                    "Signal sama dengan "
                    "signal sebelumnya."
                )


                logger.info(
                    "Tidak mengirim ulang."
                )


                return


        # ====================================================
        # FORMAT TEXT
        # ====================================================

        message = format_signal(
            result
        )


        if not message:

            logger.warning(
                "Message signal kosong."
            )


            return


        # ====================================================
        # CHART DATA
        # ====================================================

        m15_data = closed_data.get(
            "M15"
        )


        if m15_data is None:

            logger.error(
                "M15 data tidak tersedia "
                "untuk chart."
            )


            return


        # ====================================================
        # SEND CHART
        # ====================================================

        chart_success = await send_chart(
            result,
            m15_data
        )


        if not chart_success:

            logger.error(
                "Chart gagal dikirim."
            )


            logger.error(
                "Signal teks TIDAK dikirim "
                "agar chart dan signal tetap sinkron."
            )


            return


        # ====================================================
        # SEND TEXT
        # ====================================================

        text_success = await send_message(
            message
        )


        if not text_success:

            logger.error(
                "Signal teks gagal dikirim."
            )


            return


        # ====================================================
        # SEND QRIS
        # Hanya 1x sehari jam QRIS_SEND_HOUR WIB
        # ====================================================

        if should_send_qris():

            await send_qris()


        # ====================================================
        # SAVE SIGNAL
        # ====================================================

        save_sent_signal(
            {

                "signal_id":
                    signal_id,

                "signal":
                    signal,

                "confidence":
                    confidence,

                "structure":
                    structure,

                "m15_candle":
                    current_m15_key,

                "entry":
                    result["entry"],

                "sl":
                    result["sl"],

                "tp1":
                    result["tp1"],

                "tp2":
                    result["tp2"],

                "tp3":
                    result["tp3"],

                "sent_at":
                    now_wib().strftime(
                        "%Y-%m-%d %H:%M:%S WIB"
                    )
            }
        )


        logger.info(
            "=========================================="
        )


        logger.info(
            "SIGNAL + CHART BERHASIL DIKIRIM."
        )


        logger.info(
            "Signal : %s",
            signal
        )


        logger.info(
            "M15    : %s WIB",
            current_m15_key
        )


        logger.info(
            "Confidence : %s%%",
            confidence
        )


        logger.info(
            "=========================================="
        )


    except Exception as e:

        logger.exception(
            "Signal engine error: %s",
            e
        )


# ============================================================
# MAIN
# ============================================================

async def main():

    print(
        "=" * 60
    )


    print(
        "BLACK CUBE CODE"
    )


    print(
        "XAUUSD TELEGRAM SIGNAL BOT"
    )


    print(
        "M15 CLOSED CANDLE EDITION"
    )


    print(
        "=" * 60
    )


    print(
        f"ENV FILE : {ENV_FILE}"
    )


    print(
        f"CHAT ID  : {CHAT_ID}"
    )


    print(
        "TOKEN    : ADA"
    )


    print(
        f"MODE     : "
        f"{'TEST' if TEST_MODE else 'NORMAL'}"
    )


    print(
        f"WIB TIME : {format_wib()}"
    )


    print(
        "CHART    : ENABLED"
    )


    print(
        "M15      : CLOSED CANDLE ONLY"
    )


    print(
        "WEEKEND  : OFF"
    )


    print(
        "=" * 60
    )


    logger.info(
        "Bot started."
    )


    logger.info(
        "Monitoring XAUUSD..."
    )


    logger.info(
        "Signal timeframe: M15"
    )


    logger.info(
        "Strategy hanya memakai candle M15 CLOSED."
    )


    logger.info(
        "Sabtu dan Minggu: MARKET OFF."
    )


    # ========================================================
    # TELEGRAM CONNECTION
    # ========================================================

    try:

        me = await bot.get_me()


        logger.info(
            "Telegram connected: @%s",
            me.username
        )


    except Exception as e:

        logger.error(
            "Telegram connection failed: %s",
            e
        )


        return


    # ========================================================
    # TEST MODE
    # ========================================================

    if TEST_MODE:

        await run_test()


        logger.info(
            "TEST MODE selesai."
        )


        return


    # ========================================================
    # NORMAL MODE
    # ========================================================

    logger.info(
        "NORMAL MODE AKTIF."
    )


    logger.info(
        "Chart generation ENABLED."
    )


    logger.info(
        "M15 closed candle protection ENABLED."
    )


    logger.info(
        "Weekend protection ENABLED."
    )


    # ========================================================
    # MONITOR LOOP
    # ========================================================

    while True:

        try:

            await check_signal()

        except Exception as e:

            logger.exception(
                "Main loop error: %s",
                e
            )


        await asyncio.sleep(
            CHECK_INTERVAL
        )


# ============================================================
# START
# ============================================================

if __name__ == "__main__":

    try:

        asyncio.run(
            main()
        )


    except KeyboardInterrupt:

        print()


        print(
            "Bot dihentikan."
        )
