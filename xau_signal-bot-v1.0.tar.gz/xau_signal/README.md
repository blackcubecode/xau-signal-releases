XAU Signal Bot Telegram (Source Code)
Bot Telegram otomatis untuk sinyal trading XAU/USD (Gold) — analisa teknikal, filter berita, pelacakan sinyal, dan statistik win rate.
> **Produk berbayar.** Source code ini dilisensikan, bukan dijual. Lihat [LICENSE](LICENSE).
✨ Fitur
📊 Analisa teknikal otomatis multi-indikator
📰 Filter berita ekonomi high-impact
🎯 Pengiriman sinyal ke Telegram (Entry, SL, TP)
📈 Pelacakan status sinyal (TP/SL)
📉 Laporan win rate harian & mingguan
🖼️ Generator chart untuk setiap sinyal
🔄 Auto-recovery & health check
📋 Requirements
Python 3.10+ — download
Telegram Bot Token — buat sendiri via @BotFather
Telegram Chat ID — dapatkan via @userinfobot
License Key — dari penjual setelah pembelian
🚀 Instalasi
1. Extract source code
```bash
tar -xzf xau_signal.tar.gz
cd xau_signal
```
2. Buat virtual environment
Windows (PowerShell):
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```
Linux / macOS:
```bash
python3 -m venv .venv
source .venv/bin/activate
```
3. Install dependencies
```bash
pip install -r requirements.txt
```
4. Buat bot Telegram sendiri
Buka Telegram, cari @BotFather.
Kirim `/newbot`.
Berikan nama bot (bebas).
Berikan username bot (harus diakhiri `bot`, contoh: `xau_signal_anda_bot`).
BotFather akan memberikan token (format contoh: `123456789:ABCdef...`).
Salin token tersebut untuk digunakan di file `.env`.
5. Dapatkan Chat ID
Buka Telegram, cari @userinfobot.
Kirim `/start`.
Bot akan membalas dengan ID kamu (angka).
Salin ID tersebut untuk digunakan di file `.env`.
Catatan: Jika ingin mengirim sinyal ke grup atau channel, tambahkan bot sebagai admin, lalu ambil Chat ID grup (biasanya diawali `-100...`).
6. Konfigurasi `.env`
Salin `.env.example` menjadi `.env`.
Windows (PowerShell):
```powershell
Copy-Item .env.example .env
```
Linux / macOS:
```bash
cp .env.example .env
```
Buka file `.env`, lalu isi nilai berikut sesuai konfigurasi kamu:
```ini
TELEGRAM_BOT_TOKEN=123456789:ABCdef...
TELEGRAM_CHAT_ID=123456789
XAU_LICENSE_KEY=abcdef1234567890abcdef1234567890
```
> ⚠️ **Penting:** Jangan commit atau membagikan file `.env` ke Git atau pihak lain. File ini berisi token dan kredensial rahasia.
7. Jalankan bot
```bash
python telegram_bot.py
```
Jika berhasil, terminal akan menampilkan pesan serupa dengan contoh berikut:
```text
✅ Lisensi valid. Bot siap dijalankan.
============================================================
BLACK CUBE CODE
XAUUSD TELEGRAM SIGNAL BOT
============================================================
ENV FILE : ...\.env
CHAT ID  : 123456789
TOKEN    : ...OK
...
Telegram connected: @bot_kamu
```
🔑 Environment Variables
Variable	Wajib	Deskripsi
`TELEGRAM_BOT_TOKEN`	✅	Token dari @BotFather
`TELEGRAM_CHAT_ID`	✅	Chat ID tujuan pengiriman sinyal
`XAU_LICENSE_KEY`	✅	License key dari penjual (terikat ke Chat ID)
🛠️ Troubleshooting
❌ Lisensi tidak valid
Pastikan `XAU_LICENSE_KEY` dan `TELEGRAM_CHAT_ID` berpasangan. License key hanya valid untuk Chat ID yang terdaftar.
Periksa apakah ada spasi atau karakter tersembunyi saat menyalin nilai.
Hubungi penjual jika masalah berlanjut.
Telegram connection failed: Unauthorized
Token di `.env` salah atau sudah dicabut (revoked).
Buat token baru melalui @BotFather → `/mybots` → API Token.
Chat not found
Kirim `/start` ke bot kamu terlebih dahulu di Telegram.
Pastikan `TELEGRAM_CHAT_ID` sudah benar.
Untuk grup atau channel, pastikan bot telah ditambahkan dan memiliki izin yang diperlukan.
ModuleNotFoundError
Pastikan virtual environment aktif.
Jalankan kembali:
```bash
pip install -r requirements.txt
```
📄 Lisensi
Software ini bersifat proprietary dan dilisensikan, bukan dijual. Lihat file LICENSE untuk ketentuan lengkap.
✅ Boleh: Menggunakan untuk keperluan pribadi atau internal usaha.
❌ Dilarang: Menjual ulang, mendistribusikan, memodifikasi, atau melakukan reverse engineering, kecuali diizinkan secara tertulis dalam lisensi.
⚠️ Disclaimer
Bot ini merupakan alat bantu analisa dan bukan jaminan profit. Trading forex dan emas memiliki risiko tinggi. Selalu gunakan manajemen risiko yang baik dan pertimbangkan kondisi keuangan serta pengalaman trading sebelum mengambil keputusan.
📞 Kontak
BLACK CUBE CODE
Telegram: @blackcubecodeadmin
Email: blackcubecodex@gmail.com
© 2026 blackcubecode. All rights reserved.