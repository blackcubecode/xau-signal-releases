"""
License verification untuk XAU Signal Bot Telegram.
Model: offline key check, secret di-obfuscate (base64, dipecah).
"""
import os
import hashlib
import base64
import sys

# Secret di-obfuscate (base64, dipecah 3 bagian)
# JANGAN ubah ini — kalau diubah, semua license key tidak valid.
_P1 = "<PART1>"
_P2 = "<PART2>"
_P3 = "<PART3>"


def _get_secret() -> str:
    """Decode secret dari 3 bagian base64."""
    try:
        b64 = _P1 + _P2 + _P3
        return base64.b64decode(b64).decode("utf-8")
    except Exception:
        return ""


def _get_key() -> str:
    return os.getenv("XAU_LICENSE_KEY", "").strip()


def _get_chat_id() -> str:
    return os.getenv("TELEGRAM_CHAT_ID", "").strip()


def generate_key(chat_id: str, secret: str = None) -> str:
    """Generate license key untuk chat_id (dipakai penjual)."""
    secret = secret or _get_secret()
    raw = f"{chat_id}:{secret}".encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:32]


def verify_license(strict: bool = True) -> bool:
    """Verifikasi license key dari .env."""
    # Load .env kalau ada
    try:
        from dotenv import load_dotenv
        env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
        if os.path.exists(env_path):
            load_dotenv(env_path)
    except ImportError:
        pass

    key = _get_key()
    chat_id = _get_chat_id()

    if not key or not chat_id:
        msg = (
            "❌ LISENSI TIDAK DITEMUKAN\n"
            "Pastikan file .env berisi:\n"
            "  XAU_LICENSE_KEY  = <key dari penjual>\n"
            "  TELEGRAM_CHAT_ID = <chat id kamu>"
        )
        if strict:
            print(msg, file=sys.stderr)
            sys.exit(1)
        return False

    expected = generate_key(chat_id)
    if key != expected:
        msg = (
            "❌ LISENSI TIDAK VALID\n"
            "License key tidak cocok dengan Chat ID.\n"
            "Hubungi penjual jika masalah berlanjut."
        )
        if strict:
            print(msg, file=sys.stderr)
            sys.exit(1)
        return False

    print("✅ Lisensi valid. Bot siap dijalankan.")
    return True


if __name__ == "__main__":
    if len(sys.argv) >= 2:
        chat_id = sys.argv[1]
        print(f"Chat ID : {chat_id}")
        print(f"Key     : {generate_key(chat_id)}")
    else:
        print("Usage: python license_check.py <CHAT_ID>")