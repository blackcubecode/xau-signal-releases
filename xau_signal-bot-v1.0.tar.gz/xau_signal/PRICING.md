# Paket Lisensi

## 🥉 Starter
- 1 instance bot
- 1 Chat ID
- Update minor
- **Harga:** Rp 500.000

## 🥈 Professional
- 1 instance bot
- 3 Chat ID
- Update minor + major
- Dukungan email 30 hari
- **Harga:** Rp 750.000

## 🥇 Business
- 1 instance bot
- 10 Chat ID
- Update seumur hidup
- Dukungan prioritas 90 hari
- **Harga:** Rp 1000000

---

**Cara beli:**
1. Hubungi blackcubecodex@gmail.com atau Telegram @blackcubecodeadmin
2. Sebutkan paket + Chat ID yang akan didaftarkan
3. Lakukan pembayaran
4. Terima license key via email
5. Jalankan bot sesuai [README](README.md)

> License key terikat ke Chat ID — tidak dapat dipindahtangankan.