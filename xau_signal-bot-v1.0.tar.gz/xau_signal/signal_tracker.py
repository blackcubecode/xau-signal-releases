"""
BLACK CUBE CODE - Signal Tracker V3.2

Progressive TP Tracking:
- TP1 HIT -> signal tetap PENDING
- TP2 HIT -> signal tetap PENDING
- TP3 HIT -> WIN FINAL
- SL HIT  -> LOSS FINAL
- TIMEOUT -> EXPIRED

Database lama tetap kompatibel.
"""

import sqlite3
import logging
from datetime import datetime, timezone, timedelta
from pathlib import Path

logger = logging.getLogger(__name__)

DB_PATH = Path(__file__).parent / "signals_history.db"


# ============================================================
# DATABASE
# ============================================================

def init_db():
    conn = sqlite3.connect(DB_PATH)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS signals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            signal_id TEXT UNIQUE,
            signal TEXT,
            confidence INTEGER,
            structure TEXT,
            m15_candle TEXT,
            entry REAL,
            sl REAL,
            tp1 REAL,
            tp2 REAL,
            tp3 REAL,
            sent_at TEXT,
            status TEXT DEFAULT 'PENDING',
            result TEXT,
            closed_at TEXT,
            max_profit REAL DEFAULT 0,
            max_drawdown REAL DEFAULT 0
        )
    """)

    # Tambahkan kolom progressive tracking jika belum ada.
    existing_columns = {
        row[1]
        for row in conn.execute("PRAGMA table_info(signals)").fetchall()
    }

    new_columns = {
        "tp1_hit_at": "TEXT",
        "tp2_hit_at": "TEXT",
        "tp3_hit_at": "TEXT",
        "sl_hit_at": "TEXT",
        "last_event": "TEXT",
    }

    for column, column_type in new_columns.items():
        if column not in existing_columns:
            try:
                conn.execute(
                    f"ALTER TABLE signals ADD COLUMN {column} {column_type}"
                )
                logger.info("Kolom baru ditambahkan: %s", column)
            except Exception as e:
                logger.warning(
                    "Gagal menambah kolom %s: %s",
                    column,
                    e
                )

    conn.commit()
    conn.close()

    logger.info("DB signal_tracker V3.2 siap: %s", DB_PATH)


# ============================================================
# SAVE SIGNAL
# ============================================================

def save_signal(signal_data: dict):
    conn = sqlite3.connect(DB_PATH)

    try:
        conn.execute("""
            INSERT OR IGNORE INTO signals
            (
                signal_id,
                signal,
                confidence,
                structure,
                m15_candle,
                entry,
                sl,
                tp1,
                tp2,
                tp3,
                sent_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            signal_data["signal_id"],
            signal_data["signal"],
            signal_data["confidence"],
            signal_data["structure"],
            signal_data["m15_candle"],
            signal_data["entry"],
            signal_data["sl"],
            signal_data["tp1"],
            signal_data["tp2"],
            signal_data["tp3"],
            signal_data["sent_at"],
        ))

        conn.commit()

        logger.info(
            "Sinyal disimpan: %s",
            signal_data["signal_id"]
        )

    except Exception as e:
        logger.exception(
            "Gagal simpan sinyal: %s",
            e
        )

    finally:
        conn.close()


# ============================================================
# HELPER
# ============================================================

def _utc_now():
    return datetime.now(timezone.utc)


def _hit_once(row, column):
    """
    Cek apakah event TP sudah pernah tercatat.
    """
    return row[column] is not None


def _update_event(
    conn,
    row,
    event_column,
    event_name,
    current_time,
):
    """
    Catat event TP/SL dan update status.

    - TP1_HIT / TP2_HIT ? status = 'WIN' (progressive)
    - TP3_HIT ? status = 'WIN' (final)
    - SL_HIT ? status = 'LOSS'
    """

    if event_name in ("TP1_HIT", "TP2_HIT", "TP3_HIT"):
        new_status = "WIN"
    elif event_name == "SL_HIT":
        new_status = "LOSS"
    else:
        new_status = None

    if new_status:
        conn.execute(
            f"""
            UPDATE signals
            SET {event_column} = ?,
                last_event = ?,
                status = ?,
                result = ?,
                closed_at = COALESCE(closed_at, ?)
            WHERE id = ?
            """,
            (
                current_time,
                event_name,
                new_status,
                event_name,
                current_time,
                row["id"],
            )
        )
    else:
        conn.execute(
            f"""
            UPDATE signals
            SET {event_column} = ?,
                last_event = ?
            WHERE id = ?
            """,
            (
                current_time,
                event_name,
                row["id"],
            )
        )

    logger.info(
        "Sinyal %s EVENT: %s (status=%s)",
        row["signal_id"],
        event_name,
        new_status or "unchanged",
    )

    # ============================================
    # POST-LOSS COOLDOWN
    # ============================================
    if event_name == "SL_HIT":
        try:
            from strategy import mark_loss
            mark_loss()
            logger.info(
                "Post-LOSS cooldown: 120 menit (sinyal %s)",
                row["signal_id"]
            )
        except Exception as e:
            logger.warning(
                "mark_loss gagal: %s",
                e
            )


# ============================================================
# TRACK PENDING
# ============================================================

def update_pending_signals(
    current_high: float,
    current_low: float
):
    """
    Progressive tracking.

    BUY:
        SL  -> LOSS FINAL
        TP1 -> event
        TP2 -> event
        TP3 -> WIN FINAL

    SELL:
        SL  -> LOSS FINAL
        TP1 -> event
        TP2 -> event
        TP3 -> WIN FINAL

    Penting:
    Jika TP1 tercapai, signal TIDAK ditutup.
    """

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row

    try:
        pending = conn.execute(
            """
            SELECT *
            FROM signals
            WHERE status = 'PENDING'
            """
        ).fetchall()

        now = _utc_now().isoformat()

        for row in pending:

            signal = str(row["signal"]).upper()

            entry = float(row["entry"])
            sl = float(row["sl"])
            tp1 = float(row["tp1"])
            tp2 = float(row["tp2"])
            tp3 = float(row["tp3"])

            max_profit = float(row["max_profit"] or 0)
            max_drawdown = float(row["max_drawdown"] or 0)

            # ==================================================
            # BUY
            # ==================================================

            if signal == "BUY":

                max_profit = max(
                    max_profit,
                    current_high - entry
                )

                max_drawdown = min(
                    max_drawdown,
                    current_low - entry
                )

                # ------------------------------------------------
                # SL FINAL
                # ------------------------------------------------

                if current_low <= sl:

                    conn.execute("""
                        UPDATE signals
                        SET status = 'LOSS',
                            result = 'SL_HIT',
                            closed_at = ?,
                            sl_hit_at = ?,
                            last_event = 'SL_HIT',
                            max_profit = ?,
                            max_drawdown = ?
                        WHERE id = ?
                    """, (
                        now,
                        now,
                        max_profit,
                        max_drawdown,
                        row["id"],
                    ))

                    logger.info(
                        "Sinyal %s CLOSED: LOSS (SL_HIT)",
                        row["signal_id"],
                    )

                    # ============================================
                    # POST-LOSS COOLDOWN
                    # ============================================
                    try:
                        from strategy import mark_loss
                        mark_loss()
                        logger.info(
                            "Post-LOSS cooldown aktif: 120 menit (sinyal %s)",
                            row["signal_id"],
                        )
                    except Exception as _e:
                        logger.warning(
                            "mark_loss gagal: %s",
                            _e,
                        )

                    continue

                # ------------------------------------------------
                # TP1
                # ------------------------------------------------

                if (
                    current_high >= tp1
                    and not _hit_once(row, "tp1_hit_at")
                ):
                    _update_event(
                        conn,
                        row,
                        "tp1_hit_at",
                        "TP1_HIT",
                        now,
                    )

                # ------------------------------------------------
                # TP2
                # ------------------------------------------------

                if (
                    current_high >= tp2
                    and not _hit_once(row, "tp2_hit_at")
                ):
                    _update_event(
                        conn,
                        row,
                        "tp2_hit_at",
                        "TP2_HIT",
                        now,
                    )

                # ------------------------------------------------
                # TP3 FINAL WIN
                # ------------------------------------------------

                if (
                    current_high >= tp3
                    and not _hit_once(row, "tp3_hit_at")
                ):

                    conn.execute("""
                        UPDATE signals
                        SET status = 'WIN',
                            result = 'TP3_HIT',
                            closed_at = ?,
                            tp3_hit_at = ?,
                            last_event = 'TP3_HIT',
                            max_profit = ?,
                            max_drawdown = ?
                        WHERE id = ?
                    """, (
                        now,
                        now,
                        max_profit,
                        max_drawdown,
                        row["id"],
                    ))

                    logger.info(
                        "Sinyal %s CLOSED: WIN (TP3_HIT)",
                        row["signal_id"],
                    )

                    continue

                # ------------------------------------------------
                # UPDATE PROFIT / DRAWdown
                # ------------------------------------------------

                conn.execute("""
                    UPDATE signals
                    SET max_profit = ?,
                        max_drawdown = ?
                    WHERE id = ?
                """, (
                    max_profit,
                    max_drawdown,
                    row["id"],
                ))

            # ==================================================
            # SELL
            # ==================================================

            elif signal == "SELL":

                max_profit = max(
                    max_profit,
                    entry - current_low
                )

                max_drawdown = min(
                    max_drawdown,
                    entry - current_high
                )

                # ------------------------------------------------
                # SL FINAL
                # ------------------------------------------------

                if current_high >= sl:

                    conn.execute("""
                        UPDATE signals
                        SET status = 'LOSS',
                            result = 'SL_HIT',
                            closed_at = ?,
                            sl_hit_at = ?,
                            last_event = 'SL_HIT',
                            max_profit = ?,
                            max_drawdown = ?
                        WHERE id = ?
                    """, (
                        now,
                        now,
                        max_profit,
                        max_drawdown,
                        row["id"],
                    ))

                    logger.info(
                        "Sinyal %s CLOSED: LOSS (SL_HIT)",
                        row["signal_id"],
                    )

                    # ============================================
                    # POST-LOSS COOLDOWN
                    # ============================================
                    try:
                        from strategy import mark_loss
                        mark_loss()
                        logger.info(
                            "Post-LOSS cooldown aktif: 120 menit (sinyal %s)",
                            row["signal_id"],
                        )
                    except Exception as _e:
                        logger.warning(
                            "mark_loss gagal: %s",
                            _e,
                        )

                    continue

                # ------------------------------------------------
                # TP1
                # ------------------------------------------------

                if (
                    current_low <= tp1
                    and not _hit_once(row, "tp1_hit_at")
                ):
                    _update_event(
                        conn,
                        row,
                        "tp1_hit_at",
                        "TP1_HIT",
                        now,
                    )

                # ------------------------------------------------
                # TP2
                # ------------------------------------------------

                if (
                    current_low <= tp2
                    and not _hit_once(row, "tp2_hit_at")
                ):
                    _update_event(
                        conn,
                        row,
                        "tp2_hit_at",
                        "TP2_HIT",
                        now,
                    )

                # ------------------------------------------------
                # TP3 FINAL WIN
                # ------------------------------------------------

                if (
                    current_low <= tp3
                    and not _hit_once(row, "tp3_hit_at")
                ):

                    conn.execute("""
                        UPDATE signals
                        SET status = 'WIN',
                            result = 'TP3_HIT',
                            closed_at = ?,
                            tp3_hit_at = ?,
                            last_event = 'TP3_HIT',
                            max_profit = ?,
                            max_drawdown = ?
                        WHERE id = ?
                    """, (
                        now,
                        now,
                        max_profit,
                        max_drawdown,
                        row["id"],
                    ))

                    logger.info(
                        "Sinyal %s CLOSED: WIN (TP3_HIT)",
                        row["signal_id"],
                    )

                    continue

                # ------------------------------------------------
                # UPDATE PROFIT / DRAWdown
                # ------------------------------------------------

                conn.execute("""
                    UPDATE signals
                    SET max_profit = ?,
                        max_drawdown = ?
                    WHERE id = ?
                """, (
                    max_profit,
                    max_drawdown,
                    row["id"],
                ))

        conn.commit()

    except Exception as e:
        conn.rollback()

        logger.exception(
            "Update pending signals gagal: %s",
            e
        )

    finally:
        conn.close()


# ============================================================
# AUTO EXPIRE
# ============================================================

def auto_expire_old_signals(hours: int = 1):
    """
    Expire signal PENDING setelah 1 jam.

    Catatan:
    TP1/TP2 tidak menutup signal, sehingga signal yang sudah
    mencapai TP1 atau TP2 tetap aktif sampai TP3, SL, atau timeout.
    """

    conn = sqlite3.connect(DB_PATH)

    try:
        cutoff = _utc_now() - timedelta(hours=hours)

        rows = conn.execute("""
            SELECT id, signal_id, sent_at
            FROM signals
            WHERE status = 'PENDING'
        """).fetchall()

        expired = 0

        for sid, signal_id, sent_at in rows:

            if not sent_at:
                continue

            try:
                # Support format:
                # - "2026-10-15 20:45:22 WIB"
                # - "2026-10-15 20:45:22"
                # - "2026-10-15T20:45:22+00:00" (ISO)
                sent_str = str(sent_at).strip()

                if sent_str.endswith(" WIB"):
                    # Format DB: WIB
                    sent_str = sent_str[:-4].strip()
                    sent_dt = datetime.strptime(
                        sent_str,
                        "%Y-%m-%d %H:%M:%S"
                    )
                    # WIB = UTC+7
                    import pytz
                    WIB_TZ = pytz.timezone("Asia/Jakarta")
                    sent_dt = WIB_TZ.localize(sent_dt).astimezone(timezone.utc)

                else:
                    # Coba ISO format
                    sent_dt = datetime.fromisoformat(
                        sent_str.replace("Z", "+00:00")
                    )
                    if sent_dt.tzinfo is None:
                        sent_dt = sent_dt.replace(tzinfo=timezone.utc)

            except Exception as e:
                logger.warning(
                    "Format sent_at invalid untuk %s: %s (err: %s)",
                    signal_id,
                    sent_at,
                    e,
                )
                continue

            if sent_dt <= cutoff:

                now = _utc_now().isoformat()

                conn.execute("""
                    UPDATE signals
                    SET status = 'EXPIRED',
                        result = 'TIMEOUT',
                        closed_at = ?,
                        last_event = 'TIMEOUT'
                    WHERE id = ?
                      AND status = 'PENDING'
                """, (
                    now,
                    sid,
                ))

                expired += 1

                logger.info(
                    "Sinyal %s EXPIRED: TIMEOUT",
                    signal_id,
                )

        conn.commit()

        if expired:
            logger.info(
                "Auto-expire: %d sinyal ditandai EXPIRED",
                expired,
            )

    except Exception as e:

        conn.rollback()

        logger.exception(
            "Auto-expire gagal: %s",
            e
        )

    finally:
        conn.close()


# ============================================================
# STATS
# ============================================================

def get_winrate_stats(period_hours: int = 24) -> dict:
    """
    Statistik signal.

    WIN     = TP3 final
    LOSS    = SL final
    EXPIRED = timeout
    PENDING = masih aktif

    Winrate:
        WIN / (WIN + LOSS)

    TP1/TP2:
        dihitung berdasarkan event hit,
        bukan berdasarkan status final.
    """

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row

    try:

        cutoff = (
            _utc_now() -
            timedelta(hours=period_hours)
        ).isoformat()

        base = """
            FROM signals
            WHERE sent_at >= ?
        """

        total = conn.execute(
            f"""
            SELECT COUNT(*) AS c
            {base}
            """,
            (cutoff,),
        ).fetchone()["c"]

        wins = conn.execute(
            f"""
            SELECT COUNT(*) AS c
            {base}
            AND status = 'WIN'
            """,
            (cutoff,),
        ).fetchone()["c"]

        losses = conn.execute(
            f"""
            SELECT COUNT(*) AS c
            {base}
            AND status = 'LOSS'
            """,
            (cutoff,),
        ).fetchone()["c"]

        pending = conn.execute(
            f"""
            SELECT COUNT(*) AS c
            {base}
            AND status = 'PENDING'
            """,
            (cutoff,),
        ).fetchone()["c"]

        expired = conn.execute(
            f"""
            SELECT COUNT(*) AS c
            {base}
            AND status = 'EXPIRED'
            """,
            (cutoff,),
        ).fetchone()["c"]

        tp1 = conn.execute(
            f"""
            SELECT COUNT(*) AS c
            {base}
            AND tp1_hit_at IS NOT NULL
            """,
            (cutoff,),
        ).fetchone()["c"]

        tp2 = conn.execute(
            f"""
            SELECT COUNT(*) AS c
            {base}
            AND tp2_hit_at IS NOT NULL
            """,
            (cutoff,),
        ).fetchone()["c"]

        tp3 = conn.execute(
            f"""
            SELECT COUNT(*) AS c
            {base}
            AND tp3_hit_at IS NOT NULL
            """,
            (cutoff,),
        ).fetchone()["c"]

        sl = conn.execute(
            f"""
            SELECT COUNT(*) AS c
            {base}
            AND sl_hit_at IS NOT NULL
            """,
            (cutoff,),
        ).fetchone()["c"]

    except Exception as e:

        logger.exception(
            "Gagal mengambil statistik: %s",
            e
        )

        return {}

    finally:
        conn.close()

    closed = wins + losses

    if closed > 0:
        winrate = wins / closed * 100
    else:
        winrate = 0

    return {
        "total": total,
        "wins": wins,
        "losses": losses,
        "pending": pending,
        "expired": expired,
        "closed": closed,
        "winrate": round(winrate, 1),
        "tp1": tp1,
        "tp2": tp2,
        "tp3": tp3,
        "sl": sl,
    }


# ============================================================
# INITIALIZE
# ============================================================

init_db()
