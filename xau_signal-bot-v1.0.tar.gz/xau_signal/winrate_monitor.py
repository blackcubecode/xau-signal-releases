#!/usr/bin/env python3
import sys, sqlite3
sys.stdout.reconfigure(encoding="utf-8")
from datetime import datetime
from paths import DB_PATH
DB = str(DB_PATH)
conn = sqlite3.connect(DB)

print(f"\n{'='*50}")
print(f"WINRATE MONITOR ? {datetime.now().strftime('%d %b %Y, %H:%M')}")
print(f"{'='*50}\n")

# V5 (ID >= 91)
w = conn.execute("SELECT COUNT(*) FROM signals WHERE status='WIN' AND id>=91").fetchone()[0]
l = conn.execute("SELECT COUNT(*) FROM signals WHERE status='LOSS' AND id>=91").fetchone()[0]
closed = w + l
wr = (w / closed * 100) if closed > 0 else 0

print(f"? V5 WINRATE")
print(f"   Win     : {w}")
print(f"   Loss    : {l}")
print(f"   Winrate : {wr:.1f}%")
print()

# 10 sinyal terakhir
print("? 10 SINYAL TERBARU")
for r in conn.execute("""
    SELECT id, signal, confidence, status, sent_at
    FROM signals WHERE id >= 91 ORDER BY id DESC LIMIT 10
"""):
    icon = "?" if r[3] == "WIN" else "?" if r[3] == "LOSS" else "?"
    print(f"   [{r[0]}] {icon} {r[1]} conf={r[2]} | {r[4]}")

conn.close()
print()
