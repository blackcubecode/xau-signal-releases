import pandas as pd
import numpy as np

from market_data import get_market_data


# ============================================================
# INDICATOR CALCULATIONS
# ============================================================

def calculate_indicators(df, timeframe):

    if df.empty:
        return df

    df = df.copy()

    # --------------------------------------------------------
    # EMA
    # --------------------------------------------------------

    df["ema20"] = (
        df["close"]
        .ewm(span=20, adjust=False)
        .mean()
    )

    df["ema50"] = (
        df["close"]
        .ewm(span=50, adjust=False)
        .mean()
    )

    df["ema200"] = (
        df["close"]
        .ewm(span=200, adjust=False)
        .mean()
    )

    # --------------------------------------------------------
    # RSI 14
    # --------------------------------------------------------

    delta = df["close"].diff()

    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)

    avg_gain = gain.ewm(
        alpha=1 / 14,
        adjust=False
    ).mean()

    avg_loss = loss.ewm(
        alpha=1 / 14,
        adjust=False
    ).mean()

    rs = avg_gain / avg_loss.replace(0, np.nan)

    df["rsi14"] = 100 - (
        100 / (1 + rs)
    )

    # --------------------------------------------------------
    # ATR 14
    # --------------------------------------------------------

    previous_close = df["close"].shift(1)

    tr1 = df["high"] - df["low"]

    tr2 = (
        df["high"] - previous_close
    ).abs()

    tr3 = (
        df["low"] - previous_close
    ).abs()

    true_range = pd.concat(
        [tr1, tr2, tr3],
        axis=1
    ).max(axis=1)

    df["atr14"] = (
        true_range
        .ewm(alpha=1 / 14, adjust=False)
        .mean()
    )

    # --------------------------------------------------------
    # PRICE DISTANCE FROM EMA
    # --------------------------------------------------------

    df["ema20_distance"] = (
        df["close"] - df["ema20"]
    )

    df["ema50_distance"] = (
        df["close"] - df["ema50"]
    )

    # --------------------------------------------------------
    # CANDLE BODY
    # --------------------------------------------------------

    df["body"] = (
        df["close"] - df["open"]
    ).abs()

    # --------------------------------------------------------
    # CANDLE RANGE
    # --------------------------------------------------------

    df["range"] = (
        df["high"] - df["low"]
    )

    # --------------------------------------------------------
    # BULLISH / BEARISH
    # --------------------------------------------------------

    df["bullish"] = (
        df["close"] > df["open"]
    )

    df["bearish"] = (
        df["close"] < df["open"]
    )

    # --------------------------------------------------------
    # SWING HIGH / LOW
    # --------------------------------------------------------

    df["swing_high"] = (
        df["high"]
        .rolling(10)
        .max()
    )

    df["swing_low"] = (
        df["low"]
        .rolling(10)
        .min()
    )

    # --------------------------------------------------------
    # TREND
    # --------------------------------------------------------

    df["trend"] = "NEUTRAL"

    bullish_condition = (
        (df["close"] > df["ema50"]) &
        (df["ema20"] > df["ema50"])
    )

    bearish_condition = (
        (df["close"] < df["ema50"]) &
        (df["ema20"] < df["ema50"])
    )

    df.loc[
        bullish_condition,
        "trend"
    ] = "BULLISH"

    df.loc[
        bearish_condition,
        "trend"
    ] = "BEARISH"

    return df


# ============================================================
# ALL TIMEFRAMES
# ============================================================

def get_indicator_data():

    market = get_market_data()

    result = {}

    for timeframe, df in market.items():

        result[timeframe] = calculate_indicators(
            df,
            timeframe
        )

    return result


# ============================================================
# TEST
# ============================================================

if __name__ == "__main__":

    print("=" * 70)
    print("XAUUSD INDICATOR ENGINE")
    print("=" * 70)

    data = get_indicator_data()

    for timeframe, df in data.items():

        print()
        print("-" * 70)
        print(f"{timeframe} INDICATORS")

        if df.empty:
            print("DATA KOSONG")
            continue

        last = df.iloc[-1]

        print(
            f"Time       : {df.index[-1]}"
        )

        print(
            f"Close      : {last['close']:.2f}"
        )

        print(
            f"EMA20      : {last['ema20']:.2f}"
        )

        print(
            f"EMA50      : {last['ema50']:.2f}"
        )

        print(
            f"EMA200     : {last['ema200']:.2f}"
        )

        print(
            f"RSI14      : {last['rsi14']:.2f}"
        )

        print(
            f"ATR14      : {last['atr14']:.4f}"
        )

        print(
            f"Swing High : {last['swing_high']:.2f}"
        )

        print(
            f"Swing Low  : {last['swing_low']:.2f}"
        )

        print(
            f"Trend      : {last['trend']}"
        )

        print(
            f"Candle     : "
            f"{'BULLISH' if last['bullish'] else 'BEARISH'}"
        )

    print()
    print("=" * 70)
    print("INDICATOR ENGINE OK")
    print("=" * 70)
