"""Daily news review \u2014 kirim jadwal news hari ini jam 08:00 WIB."""
import os
import asyncio
import logging
import json
from datetime import datetime, timedelta
import pytz
from telegram import Bot
from dotenv import load_dotenv

from paths import ENV_FILE
load_dotenv(ENV_FILE)

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
WIB = pytz.timezone("Asia/Jakarta")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
logging.getLogger("httpx").setLevel(logging.CRITICAL)
logging.getLogger("httpcore").setLevel(logging.CRITICAL)
logging.getLogger("telegram.request").setLevel(logging.CRITICAL)
logger = logging.getLogger(__name__)

CAL = "\U0001F4C5"
CLOCK = "\U0001F550"
NEWS = "\U0001F4F0"
WARN = "\u26A0\uFE0F"
BULB = "\U0001F4A1"


def load_news():
    """Ambil news dari cache atau feed."""
    from news_filter import _fetch_feed
    return _fetch_feed()


async def send_daily_review(bot):
    try:
        events = load_news()
        if not events:
            logger.warning("Feed kosong, skip review.")
            return

        now_wib = datetime.now(WIB)
        today_wib = now_wib.date()
        tomorrow_wib = today_wib + timedelta(days=1)

        # Filter news hari ini (WIB)
        today_news = []
        for ev in events:
            if ev.get("impact", "").lower() != "high":
                continue
            if ev.get("country", "").upper() != "USD":
                continue
            try:
                ev_time = datetime.fromisoformat(ev["date"].replace("Z", "+00:00"))
                ev_wib = ev_time.astimezone(WIB)
                if ev_wib.date() == today_wib:
                    today_news.append((ev_wib, ev["title"]))
            except Exception:
                continue

        today_news.sort()

        sep = "\u2501" * 18

        lines = [
            "\U0001F4F0 NEWS HARI INI",
            sep,
            "\U0001F4C5 " + now_wib.strftime("%A, %d %b %Y"),
            "",
        ]

        if not today_news:
            lines.append("\U0001F7E2 Tidak ada news high-impact")
            lines.append("")
            lines.append("\U0001F4A1 Market relatif tenang")
        else:
            lines.append(f"\U0001F6D1 {len(today_news)} HIGH-IMPACT USD")
            lines.append("")
            for ev_wib, title in today_news:
                lines.append(f"\U0001F550 {ev_wib.strftime('%H:%M WIB')} \u2014 {title}")
            lines.append("")
            lines.append("\u26A0\uFE0F WARNING\n"
                         "Bot akan STOP TRADING 30 menit\n"
                         "sebelum & sesudah news di atas")

        lines.append("")
        lines.append("_Black Cube Code_")

        msg = "\n".join(lines)
        await bot.send_message(chat_id=CHAT_ID, text=msg, disable_web_page_preview=True)
        logger.info("Review harian terkirim (%d news)", len(today_news))

    except Exception as e:
        logger.exception("Gagal kirim review: %s", e)


def _is_weekend():
    """Cek apakah hari ini Sabtu atau Minggu."""
    return datetime.now(WIB).weekday() >= 5


async def main():
    bot = Bot(token=TOKEN)
    logger.info("Daily news review started. Kirim tiap 08:00 WIB.")

    while True:
        now = datetime.now(WIB)
        # Hitung waktu kirim berikutnya: hari ini jam 08:00 atau besok jam 08:00
        target = now.replace(hour=8, minute=0, second=0, microsecond=0)
        if now >= target:
            target = target + timedelta(days=1)

        wait_seconds = (target - now).total_seconds()
        logger.info("Next review: %s (%.1f jam lagi)",
                    target.strftime("%d %b %H:%M WIB"), wait_seconds / 3600)

        await asyncio.sleep(wait_seconds)

        # Skip kalau Sabtu/Minggu
        if _is_weekend():
            logger.info("Weekend - skip review news.")
            continue

        await send_daily_review(bot)


if __name__ == "__main__":
    asyncio.run(main())
